# -*- coding: utf-8 -*-
"""
Created on Mon Jul 27 09:58:20 2020

GUI with plotly - dash

@author: d75188
"""

# visit http://127.0.0.1:8050/ in your web browser.

import base64
from datetime import datetime, timedelta, date
import io

import dash
import dash_core_components as dcc
import dash_html_components as html
from dash.dependencies import Input, Output, State
import dash_table
from dash_table.Format import Format, Group, Scheme, Symbol
import dash_daq as daq

import pandas as pd
import numpy as np
import os

import sys
sys.path.append('C:/QRG')

from FI_API_Client.python.functions.df_fx_rates import df_fx_rates_func
from FI_API_Client.python.functions.df_swap_rates import df_swap_rates_func
from FI_API_Client.python.functions.parsing_cashflow import parsing_cashflow
from FI_API_Client.python.functions.parsing_portfolio import parsing_portfolio
import FI_API_Client.python.functions.utils as fct

from FI_API_Client.python.functions.parsing_universe import parsing_universe

#from FI_API_Server.api.codes.CashFlowBuyAndHoldAnalysis import buy_and_hold_analysis
#from FI_API_Server.api.codes.optimizer import optimizer

from FI_API_Client.python.core import QRGFixedIncomeApi
qrg_api = QRGFixedIncomeApi()


external_stylesheets = ['https://codepen.io/chriddyp/pen/bWLwgP.css']

app = dash.Dash(__name__, external_stylesheets=external_stylesheets)

colors = {
     'background_boxes': '#007348',
     'title' : '#8BC8AA',
     'subtitle' : '#39A87B',
     'text': '#007348',
     'error' : '#D8000C',
     'background_error' : '#FFD2D2',
     'S&P' : '#BDECFF',
     'Moodys' : '#BDBEFF',
     'Fitch' : '#F4BDFF',
     'no_rating' : '#FB7D7D',
     'neg_yields' : '#FBFB7D',
     'price>200' : "#FBB27D"
 }
# if there are updates in colors, change also the one in FixedIncome_BuyAndHold.src_client.functions.utils

definitions = '''
_Super gross YTM :_ Yield not considering default impact, nor capital reinvestment at fund’s maturity \n
_Gross YTM :_ Including reinvestment at maturity at cash rate and no default risk rate \n
_Estimated Gross YTM :_  Yield at maturity considering capital reinvestment at maturity at cash rate and default impact
'''

note = '''
__\*__ Bonds with a price under 80 are flagged as distressed and bonds priced under 80 will pay Ask price ∗cashflow at each cashflow payment date
'''

legend_rating_selection = '''
If BB_COMPOSITE not standard (for exemple NR - not rated) a further inquiry is made to find a rating equal to AAA, AA, A, BBB, BB, B or CCC:
Moody's rating is selected if available, S&P's otherwise, or Fitch's if previous ones not available.\n
'''


currencies = ["EUR", "USD", "GBP", "NOK", "SEK"]

one_day = timedelta(days=1)
asof_date = pd.to_datetime(date.today() - one_day) # yesterday

folder = 'Z:/Users/Antonio/CreditProject/BnH/prod ' + (str(datetime.now())[:10]).replace(':','.') + '/'

if not os.path.exists(folder):
    os.makedirs(folder)

def two_decimals(int_):
    return "{0:.2f}".format(np.round(int_, 2))
def show_correct_datetime(datetime_):
    return str(datetime_)[:10]
show_correct_datetime = np.vectorize(show_correct_datetime)

# =============================================================================
#                              LAYOUT
# =============================================================================

app.layout = html.Div(children=[
     html.H1(
             children='Buy and Hold analysis',
             style={
                     'textAlign': 'left',
                     'color': colors['title']
                     }
             ),

     html.Div( children=[
             html.Div( children=[

                     html.H4( children = 'Inputs',
                             style = {
                                     'textAlign': 'left',
                                     'color': colors['subtitle']
                                     }
                             ),

                     html.Div([
                             html.Table([
                                     html.Tr([html.Td(["Recovery rate"]),
                                              html.Td([
                                                      dcc.Input(id='input-recovery_rate',
                                                                value='41.6%',
                                                                type='text'),
                                                      html.Div(id='output-recovery_rate'),
                                                      ])
                                              ]),
                                     html.Tr([html.Td(['Portfolio\'s currency']),
                                              html.Td(
                                                      dcc.Dropdown(
                                                              id='input-cncy',
                                                              options=[{'label': i, 'value': i} for i in currencies],
                                                              value='EUR'
                #                                              style = dict(width = '25%')
                                                              )
                                                      )
                                              ]),
                                     html.Tr([html.Td(['Excess expected reinvestment rate over forward swap rates']),
                                              html.Td([
                                                      dcc.Input(id='input-reinvest_rate', value='0.0%', type='text'),
                                                      html.Div(id='output-reinvest_rate')
                                                      ]
                                                      )
                                              ]),
                             # =============================================================================
                             # Removed "Complete portfolio data" since in this code the NR are
                             # treated automatically
                             # =============================================================================
                                     html.Tr([html.Td(['Penalize distressed bonds (prices under 80) *']),
                                              html.Td(
                                                      dcc.RadioItems(
                                                              id='input-penalized_bonds',
                                                              options=[{'label': 'True', 'value' : 'True'},
                                                                       {'label': 'False', 'value' : 'False'}],
                                                              value = 'True',
                                                              labelStyle={'display': 'inline-block'}
                                                              )
                                                      )
                                              ]),
                                    ]),
                             ]),
                     ], style={'width': '40%', 'display': 'inline-block'} ),
        ]),

    dcc.Markdown(children=note,
                 style = {'width' : '49%',
                          'fontSize':12,
                          'textAlign': 'left',
                          'display': 'inline-block'
                 }),
# =============================================================================
#     OPTIMIZER
# =============================================================================

    html.H2(
             children='Optimizer',
             style={
                     'textAlign': 'left',
                     'color': colors['subtitle']
                     }
             ),

    dcc.RadioItems(
            id='input-use_of_optimizer',
            options=[{'label': 'Yes', 'value' : 'Yes'},
                     {'label': 'No', 'value' : 'No'}],
            value = 'No',
            labelStyle={'display': 'inline-block'}
            ),

    html.Div(id='optimizer_yes',
            children = [

    html.Div( children=[
             html.Div( children=[

                     html.H4( children = 'Constraints',
                             style = {
                                     'textAlign': 'left',
                                     'color': colors['subtitle']
                                     }
                             ),

                     html.Div([
                             html.Table([
                                    html.Tr([
                                            html.Td(['Energy sector']),
                                            html.Td([
                                                      dcc.RadioItems(
                                                              id='input-energy_sector',
                                                              options=[{'label': 'Yes', 'value' : 'Yes'},
                                                                       {'label': 'No', 'value' : 'No'}],
                                                              value = 'No',
                                                              labelStyle={'display': 'inline-block'}
                                                              )
                                                      ]),
                                            html.Td(['Senior bonds only']),
                                            html.Td([
                                                      dcc.RadioItems(
                                                              id='input-senior_bonds_only',
                                                              options=[{'label': 'Yes', 'value' : 'Yes'},
                                                                       {'label': 'No', 'value' : 'No'}],
                                                              value = 'No',
                                                              labelStyle={'display': 'inline-block'}
                                                              )
                                                      ]),
                                              ]),
                                    html.Tr([
                                            html.Td(['Maximum weight for investments HY']),
                                            html.Td([
                                                    dcc.Input(id='input-num_Max_HY', value='30%', type='text'),
                                                    html.Div(id='output-num_Max_HY')
                                                    ]),
                                            html.Td(['Rating greater than B-']),
                                            html.Td([
                                                      dcc.RadioItems(
                                                              id='input-greater_B3',
                                                              options=[{'label': 'Yes', 'value' : 'Yes'},
                                                                       {'label': 'No', 'value' : 'No'}],
                                                              value = 'Yes',
                                                              labelStyle={'display': 'inline-block'}
                                                              )
                                                      ]),
                                              ]),
                                    html.Tr([
                                            html.Td(['Reinvestment impact']),
                                            html.Td([
                                                      dcc.RadioItems(
                                                              id='input-bool_Reinv',
                                                              options=[{'label': 'Yes', 'value' : 'Yes'},
                                                                       {'label': 'No', 'value' : 'No'}],
                                                              value = 'No',
                                                              labelStyle={'display': 'inline-block'}
                                                              )
                                                      ]),
                                            html.Td(['Default impact']),
                                            html.Td([
                                                      dcc.RadioItems(
                                                              id='input-bool_Default',
                                                              options=[{'label': 'Yes', 'value' : 'Yes'},
                                                                       {'label': 'No', 'value' : 'No'}],
                                                              value = 'Yes',
                                                              labelStyle={'display': 'inline-block'}
                                                              )
                                                      ]),
                                              ]),
                                    html.Tr([
                                            html.Td(['Maximum weight for sector']),
                                            html.Td([
                                                      dcc.Input(id='input-max_sector_weight', value='100%', type='text'),
                                                      html.Div(id='output-max_sector_weight')
                                                      ]),
                                            html.Td(['Maximum weight for country']),
                                            html.Td([
                                                      dcc.Input(id='input-max_country_weight', value='100%', type='text'),
                                                      html.Div(id='output-max_country_weight')
                                                      ]),
                                              ]),
                                    html.Tr([
                                            html.Td(['Maximum weight for issuer - IG']),
                                            html.Td([
                                                      dcc.Input(id='input-max_issuer_weight_IG', value='5%', type='text'),
                                                      html.Div(id='output-max_issuer_weight_IG')
                                                      ]),
                                            html.Td(['Maximum weight for issuer - HY']),
                                            html.Td([
                                                      dcc.Input(id='input-max_issuer_weight_HY', value='3%', type='text'),
                                                      html.Div(id='output-max_issuer_weight_HY')
                                                      ]),
                                              ]),
                                    html.Tr([
                                            html.Td(['Maximum weight for ISIN']),
                                            html.Td([
                                                      dcc.Input(id='input-max_ISIN_weight', value='2.5%', type='text'),
                                                      html.Div(id='output-max_ISIN_weight')
                                                      ]),
                                            html.Td(['Percentage of portfolio allocated']),
                                            html.Td([
                                                      dcc.Input(id='input-Max_SumWeight', value='100%', type='text'),
                                                      html.Div(id='output-Max_SumWeight')
                                                      ]),
                                            ]),
                                      html.Tr([
                                            html.Td(['Bonds maturity - starting date']),
                                            html.Td([
                                                    dcc.Dropdown(
                                                            id='input-bonds_maturity_start',
                                                            options=[{'label': i, 'value': i} for i in range(2020,2030)],
                                                            value=2025
#                                                            style = dict(width = '25%')
                                                            ),
                                                    ]),
                                            html.Td(['Bonds maturity - ending date']),
                                            html.Td([
                                                    dcc.Dropdown(
                                                            id='input-bonds_maturity_end',
                                                            options=[{'label': i, 'value': i} for i in range(2020,2030)],
                                                            value=2025
              #                                              style = dict(width = '25%')
                                                            ),
                                                    html.Div(id='output-bonds_maturity')
                                                    ]),
                                             ]),
                                    html.Tr([
                                            html.Td(['Callable bonds']),
                                            html.Td([
                                                      dcc.RadioItems(
                                                              id='input-callable_bonds',
                                                              options=[{'label': 'Yes', 'value' : 'Yes'},
                                                                       {'label': 'No', 'value' : 'No'}],
                                                              value = 'No',
                                                              labelStyle={'display': 'inline-block'}
                                                              )
                                                      ]),
                                            html.Td([]),
                                            html.Td([]),
                                            ]),

                                    ]),
                             ]),
                     ], style={'width': '60%', 'display': 'inline-block'} ),
        ]),
    dcc.Store(id='store-constraints'),

    html.H3( children = 'Universe',
             style = {
                     'textAlign': 'left',
                     'color': colors['subtitle']
                     }
             ),
    
    html.Table([
            html.Tr([
                    html.Td(['BBG xla activation path']),
                    html.Td([
                            dcc.Input(id='input-bbg_xla',
                                      value="C:/Program Files (x86)/BLOOMBRG/OBLMBERG/API/Office Tools/BloombergUI.xla",
                                      type='text',
                                      size = '80'),
                            ]),
                    ]),
            html.Tr([
                    html.Td(['BBG dll activation path']),
                    html.Td([
                            dcc.Input(id='input-bbg_dll',
                                      value="C:/Program Files (x86)/BLOOMBRG/OBLMBERG/API/Office Tools/bofaddin.dll",
                                      type='text',
                                      size = '80'),
                            ]),
                    ]),
#            html.Tr([
#                    html.Td(['Path towards the list of bonds']),
#                    html.Td([
#                            dcc.Input(id='input-list_bonds_path',
#                                      value="Z:/Users/Laure/test bbg 17.xlsx",
#                                      type='text',
#                                      size = '80'),
#                            ]),
#                    ]),
            ], style={'width': '100%', 'display': 'inline-block'} ),

    html.H4( children = 'List tickers',
            style = {
                    'textAlign': 'left',
                    'color': colors['subtitle']
                    }
                             ),
    html.Div( children = [
            dcc.Upload(
                id='upload-list_tickers',
                children=html.Div([
                    'Drag and Drop or ',
                    html.A('Select Files')
                ]),
                style={
                    'width': '50%',
                    'height': '60px',
                    'lineHeight': '60px',
                    'borderWidth': '1px',
                    'borderStyle': 'dashed',
                    'borderRadius': '5px',
                    'textAlign': 'center',
                    'margin': '10px'
                },
                # Allow multiple files to be uploaded
                multiple=False
            ),
    ]),

    dcc.Store(id='store-uploaded-list_tickers'),
    html.Div(id = 'show-upload_list_tickers',
             children =[
                    dash_table.DataTable(
                        id='uploaded_list_tickers',
                        children = [],
                        columns = [],
                        editable = True,
                        row_deletable = True,
                        )],
            style={
                    'width': '25%'
                }),
    html.Button('Add Row', id='adding-rows-button-list_tickers', n_clicks=0, style = dict(display='none')),
    dcc.Store(id='store-list_tickers_modified'),
                    

    html.Button('Parsing universe', id='button-parsing_universe',
                n_clicks=0,
                style = dict(display='none')
                ),
                            
#    html.Div( children = [
#            dcc.Upload(
#                id='upload-universe',
#                children=html.Div([
#                    'Drag and Drop or ',
#                    html.A('Select Files')
#                ]),
#                style={
#                    'width': '50%',
#                    'height': '60px',
#                    'lineHeight': '60px',
#                    'borderWidth': '1px',
#                    'borderStyle': 'dashed',
#                    'borderRadius': '5px',
#                    'textAlign': 'center',
#                    'margin': '10px'
#                },
#                # Allow multiple files to be uploaded
#                multiple=False
#            ),
#    ]),
    

    html.Div([
        dcc.Input(
            id='adding-columns-name-universe',
            placeholder='Enter a column name...',
            value='',
            style = dict(display='none')
#            style={'padding': 10}
        ),
        html.Button('Add Column', id='adding-columns-button-universe', n_clicks=0, style = dict(display='none'))
    ], style={'height': 50}
    ),


    dcc.Store(id='store-uploaded-universe'),
    html.Div(id = 'show-upload_universe',
             children =[
                    dash_table.DataTable(
                        id='uploaded_universe',
                        children = [],
                        columns = [],
                        editable = True,
                        row_deletable = True,
                        )],
            style={
                    'width': '25%'
                }),
    html.Button('Add Row', id='adding-rows-button-universe', n_clicks=0, style = dict(display='none')),
    dcc.Store(id='store-universe_modified'),

    html.Button('Launch optimizer', id='button-launch-optimizer',
                n_clicks=0,
                style = dict(display='none')
                ),
    html.H4( id = 'name-table-optimizer',
            children = 'Portfolio',
             style = dict(display='none')
             ),
    html.Div( children =[
            dash_table.DataTable(
                id='table-optimizer',
                children = [],
                columns = [],
                editable = True,
                row_deletable = True,
                )],
            style={
                    'width': '25%'
                }),
    dcc.Markdown(id= 'markdown-paym_dates-optim',
                 children='',
                     style = {'width' : '70%',
                              'textAlign': 'left',
                              'fontSize':12,
                              'display': 'inline-block'
                    })

            ],
            style = dict(display='none')
    ),

    html.Div(id='optimizer_no',
            children = [
# =============================================================================
# PAYMENT DATES
# =============================================================================
                    html.H4( children = 'Payment dates',
                             style = {
                                     'textAlign': 'left',
                                     'color': colors['subtitle']
                                     }
                             ),
                    html.Div( children = [
                            dcc.Upload(
                                id='upload-payment_dates',
                                children=html.Div([
                                    'Drag and Drop or ',
                                    html.A('Select Files')
                                ]),
                                style={
                                    'width': '50%',
                                    'height': '60px',
                                    'lineHeight': '60px',
                                    'borderWidth': '1px',
                                    'borderStyle': 'dashed',
                                    'borderRadius': '5px',
                                    'textAlign': 'center',
                                    'margin': '10px'
                                },
                                # Allow multiple files to be uploaded
                                multiple=False
                            ),
                    ]),



# =============================================================================
# Building payment dates if not from file
# =============================================================================
                    html.Div( children=[
                                     html.H5( children = 'Payment dates construction',
                                             style = {
                                                     'textAlign': 'left',
                                                     'color': colors['subtitle']
                                                     }
                                             ),

                                     html.Table([
                                             html.Table( id = 'table-coupon' , children = [
                                                     html.Tr(
                                                             html.H6( children = 'Coupons',
                                                                     style = {
                                                                             'textAlign': 'left',
                                                                             'color': colors['subtitle']
                                                                             }
                                                                     ),),
                                                     html.Tr([
                                                             html.Td(['Unique value']),
                                                              html.Td(
                                                                      dcc.RadioItems(
                                                                              id='unique_value-coupon',
                                                                              options=[{'label': i, 'value': i} for i in ['Yes','No']],
                                                                              value='Yes',
                                                                              labelStyle={'display': 'inline-block'}
                                                                              )
                                                                      )
                                                              ]),
                                                    html.Tr(id = 'coupon-hide-starting-date-cell',
                                                            children = [
                                                                    html.Td(["Starting date"]),
                                                                    html.Td([
                                                                              dcc.Input(id='input-coupon-starting_date',
                                                                                        value= str(asof_date)[:10],
                                                                                        type='text'),
                                                                              html.Div(id='output-coupon-starting_date'),
                                                                              ])
                                                              ], hidden = True),
                                                    html.Tr(id = 'coupon-hide-max_maturity-cell',
                                                            children = [
                                                                    html.Td(['Max maturity as ending date']),
                                                                    html.Td([
                                                                            dcc.RadioItems(
                                                                                    id='coupon-max_maturity-ending_date',
                                                                                    options=[{'label': i, 'value': i} for i in ['Yes','No']],
                                                                                    value='No',
                                                                                    labelStyle={'display': 'inline-block'}
                                                                                    )
                                                                    ])
                                                                ], hidden = True),

                                                    html.Tr([html.Td(["Ending date"]),
                                                             html.Td([
                                                                      dcc.Input(id='input-coupon-ending_date',
                                                                                value= str(asof_date)[:10],
                                                                                type='text'),
                                                                      html.Div(id='output-coupon-ending_date'),
                                                                      ])
                                                             ]),
                                                    html.Tr(id = 'coupon-hide-frequency-cell',
                                                            children = [
                                                                    html.Td(["Frequency"]),
                                                                    html.Td([
                                                                            dcc.Dropdown(id='input-coupon-frequency',
                                                                                         options=[{'label': 'Manual modification', 'value': 'Manual modification'}]+[
                                                                                                 {'label': str(i)+'M', 'value': str(i)+'M'} for i in range(1,13)],
                                                                                         value = 'None'),
                                                                    ])
                                                             ], hidden = True),
                                                    html.Tr([html.Td(['Adding ending date']),
                                                             html.Td([
                                                                      dcc.RadioItems(
                                                                              id='adding-coupon-ending_date',
                                                                              options=[{'label': i, 'value': i} for i in ['Yes','No']],
                                                                              value='No',
                                                                              labelStyle={'display': 'inline-block'}
                                                                              )
                                                                      ])
                                                              ]),
                                                    ]),#end table coupon


                                             html.Table( id = 'table-notional' , children = [
                                                    html.Tr(
                                                            html.H6( children = 'Notional',
                                                                     style = {
                                                                             'textAlign': 'left',
                                                                             'color': colors['subtitle']
                                                                             }
                                                                     ),),
                                                    html.Tr([html.Td(['Unique value']),
                                                              html.Td(
                                                                      dcc.RadioItems(
                                                                              id='unique_value-notional',
                                                                              options=[{'label': i, 'value': i} for i in ['Yes','No']],
                                                                              value='Yes',
                                                                              labelStyle={'display': 'inline-block'}
                                                                              )
                                                                      )
                                                              ]),
                                                    html.Tr(id = 'notional-hide-starting-date-cell',
                                                            children = [
                                                                    html.Td(["Starting date"]),
                                                                    html.Td([
                                                                              dcc.Input(id='input-notional-starting_date',
                                                                                        value= str(asof_date)[:10],
                                                                                        type='text'),
                                                                              html.Div(id='output-notional-starting_date'),
                                                                              ])
                                                              ], hidden = True),
                                                    html.Tr(id = 'notional-hide-max_maturity-cell',
                                                            children = [
                                                                    html.Td(['Max maturity as ending date']),
                                                                    html.Td([
                                                                            dcc.RadioItems(
                                                                                    id='notional-max_maturity-ending_date',
                                                                                    options=[{'label': i, 'value': i} for i in ['Yes','No']],
                                                                                    value='No',
                                                                                    labelStyle={'display': 'inline-block'}
                                                                                    ),
                                                                    ])
                                                                ], hidden = True),
                                                    html.Tr([html.Td(["Ending date"]),
                                                             html.Td([
                                                                      dcc.Input(id='input-notional-ending_date',
                                                                                value= str(asof_date)[:10],
                                                                                type='text'),
                                                                      html.Div(id='output-notional-ending_date'),
                                                                      ])
                                                             ]),
                                                    html.Tr(id = 'notional-hide-frequency-cell',
                                                            children = [
                                                                    html.Td(["Frequency"]),
                                                                    html.Td([
                                                                            dcc.Dropdown(id='input-notional-frequency',
                                                                                         options=[{'label': 'Manual modification', 'value': 'Manual modification'}]+[
                                                                                                 {'label': str(i)+'M', 'value': str(i)+'M'} for i in range(1,13)],
                                                                                         value = 'None'),
                                                                    ])
                                                             ], hidden = True),
                                                    html.Tr([html.Td(['Adding ending date']),
                                                             html.Td([
                                                                      dcc.RadioItems(
                                                                              id='adding-notional-ending_date',
                                                                              options=[{'label': i, 'value': i} for i in ['Yes','No']],
                                                                              value='No',
                                                                              labelStyle={'display': 'inline-block'}
                                                                              )
                                                                      ])
                                                              ]),
                                                    ]), #end table notional
                                             ]), #end table coupon+notional
                                     ], style={'width': '60%'#, 'display': 'inline-block'
                                        } ),

                    html.Button('Build payment dates', id='button-build_payment_dates',
                                n_clicks=0,
                                style = {
                                        'width': '200px',
                                        'height': '40px',
                                        'lineHeight': '30px',
                                        'borderWidth': '2px',
                                        'borderStyle': 'outset',
                                        'borderRadius': '4px',
                                        'textAlign': 'center',
                                        'margin': '10px',
                                        'backgroundColor': colors['title'],
                                        'color': 'white',
                                        'vertical-align': 'middle',
                                        'fontSize':11,
                                    }
                                ),
                    html.Div(id='output-error-payment_build'),


                    html.Div(id='error_messages_payment_dates'),
                    dcc.Store(id='store-fromconstructor-payment_dates'),
                    dcc.Store(id='store-uploaded-payment_dates'),


                    html.Div([
                        dcc.Input(
                            id='adding-columns-name-payment_dates',
                            placeholder='Enter a column name...',
                            value='',
                            style = dict(display='none')
                #            style={'padding': 10}
                        ),
                        html.Button('Add Column', id='adding-columns-button-payment_dates', n_clicks=0, style = dict(display='none'))
                    ], style={'height': 50}
                    ),
                    html.Div(id = 'show-upload_payment_dates',
                             children =[
                                    dash_table.DataTable(
                                        id='uploaded_payment_dates',
                                        children = [],
                                        columns = [],
                                        editable = True,
                                        row_deletable = True,
                                        )],
                            style={
                                    'width': '25%'
                                }),
                    html.Button('Add Row', id='adding-rows-button-payment_dates', n_clicks=0, style = dict(display='none')),
                    #------------------------------------------------------------------------------

                    dcc.Store(id='store-payment_dates_modified'),



# =============================================================================
# PORTFOLIO
# =============================================================================

                    html.H3( children = 'Portfolio',
                             style = {
                                     'textAlign': 'left',
                                     'color': colors['subtitle']
                                     }
                             ),

                    html.Div( children = [
                        dcc.Upload(
                            id='upload-portfolio',
                            children=html.Div([
                                'Drag and Drop or ',
                                html.A('Select Files')
                            ]),
                            style={
                                'width': '50%',
                                'height': '60px',
                                'lineHeight': '60px',
                                'borderWidth': '1px',
                                'borderStyle': 'dashed',
                                'borderRadius': '5px',
                                'textAlign': 'center',
                                'margin': '10px'
                            },
                            # Allow multiple files to be uploaded
                            multiple=False
                        )
                    ]),
                    html.Div(id='error_messages_portfolio'),
                    html.Div([
                        dcc.Input(
                            id='adding-columns-name-portfolio',
                            placeholder='Enter a column name...',
                            value='',
                            style = dict(display='none')
                #            style={'padding': 10}
                        ),
                        html.Button('Add Column', id='adding-columns-button-portfolio', n_clicks=0, style = dict(display='none'))
                    ], style={'height': 50}
                    ),

                    dcc.Store(id='store-uploaded-portfolio'),
                    dcc.Store(id='correct_input_portfolio'),
                    html.Div(
                             children =[
                                    dash_table.DataTable(
                                        id='uploaded_portfolio-to_screen',
                                        children = [],
                                        columns = [],
                                        editable = True,
                                        row_deletable = True,
                                        )],
                            style={
                                    'width': '25%'
                                }),
                    html.Button('Add Row', id='adding-rows-button-portfolio', n_clicks=0, style = dict(display='none')),
                    html.Button('Delete', id='delete-button-portfolio', n_clicks=0, style = dict(display='none')),
                    #--------------------------------------------------------------------------

            ], # ending oputm_no
            style = dict(display='none')
    ),

    html.Button('Check portfolio', id='button-check-portfolio',
                n_clicks=0,
                style = dict(display='none')
                ),
    html.Div( children =[
            dash_table.DataTable(
                id='table-portfolio_after_bbg',
                children = [],
                columns = [],
                editable = True,
                row_deletable = True,
                )],
            style={
                    'width': '25%'
                }),
    dcc.Store(id='store-portfolio_from_bbg'),
    dcc.Store(id='store-rating_from_SandP'),
    dcc.Store(id='store-rating_from_Moodys'),
    dcc.Store(id='store-rating_from_Fitch'),
    dcc.Store(id='store-bdp_result'),
    dcc.Store(id='store-weight_cash'),
    dcc.Store(id='store-portfolio_modified'),

    html.Div( children = [
            dcc.Markdown(
                    id = 'legend_rating_selection',
                    children='',
                    style = {'width' : '49%',
                             'fontSize':12,
                             'textAlign': 'left',
                             'display': 'inline-block'
                    }),
            html.Div(id = 'labels',
                     style = {'width': '7%',
                             })
            ]
    ),
    html.Div(id='error_messages_payment_dates-max_maturity'),

    html.Br(), # to insert empty line

    # =============================================================================

    html.Div( children=[
                html.Button('Compute Yields', id='compute-yields',
                            n_clicks=0,
                            style={
                                'width': '250px',
                                'height': '60px',
                                'lineHeight': '60px',
                                'borderWidth': '2px',
                                'borderStyle': 'outset',
                                'borderRadius': '5px',
                                'textAlign': 'center',
                                'margin': '10px',
                                'backgroundColor': colors['background_boxes'],
                                'color': 'white',
                                'vertical-align': 'middle',
                                'fontSize':20,
                            }),
                 ], style={'width': '60%',
                            'height': '350px',
                            'display': 'inline-block',
                            'textAlign': 'center'}
                    ),
     html.Div( children=[
            html.H2( children = 'Outputs',
                     style = {
                             'textAlign': 'left',
                             'color': colors['subtitle']
                             }
                     ),
            html.Div([
                     html.Table([
                             html.Tr([html.Td(["Super Gross YTM"]),
                                      html.Td(id='super-gross-YTM')
                                      ]),
                             html.Tr([html.Td(['Gross YTM']),
                                      html.Td(id='gross-YTM')
                                      ]),
                             html.Tr([html.Td(['Estimated Gross YTM']),
                                      html.Td(id='estimated-gross-YTM')
                                      ]),
                            ]),
                     ])
             ], style={'width': '30%',
                'display': 'inline-block',
                'textAlign': 'right'}
            ),
        dcc.Markdown(children=definitions,
                     style = {'width' : '70%',
                              'textAlign': 'right',
                              'fontSize':12,
                              'display': 'inline-block'
                    }),
])

















# =============================================================================
# Callback functions
# =============================================================================

#taking inputs
@app.callback(
    [Output('output-recovery_rate', 'children'),
     Output('output-reinvest_rate', 'children'),
     Output('store-uploaded-portfolio', 'data'),
     Output('store-uploaded-payment_dates', 'data'),
     ],

    [Input("input-recovery_rate",'value'),
     Input('input-cncy', 'value'),
     Input('input-reinvest_rate', 'value'),
     Input('input-penalized_bonds', 'value'),

     Input('upload-portfolio', 'contents'),
     Input('upload-payment_dates', 'contents')],

     [State('upload-portfolio', 'filename'),
      State('upload-payment_dates', 'filename'),
     ]
    )

def callback_initial_inputs(recovery_rate, cncy, reinvest_rate, penalized_bonds, portfolio, payment_dates,
               name_portfolio, name_payment_dates):
    '''
    taking the input parameters, checking if there are mistake for the first ones and saving to a store
    portfolio and payment dates dataframes, if any
    '''

    recovery_error = [fct.error(recovery_rate)]
    reinvest_rate_error = [fct.error(reinvest_rate)]

    if portfolio is not None :
        new_portfolio = fct.parse_contents(portfolio, name_portfolio, 'portfolio')
        new_portfolio = new_portfolio.to_dict('records')
    else:
        new_portfolio = None
    if payment_dates is not None:
        new_payment_dates = fct.parse_contents(payment_dates, name_payment_dates, 'payment_dates')
        new_payment_dates = new_payment_dates.to_dict('records')
    else:
        new_payment_dates = None

    return recovery_error, reinvest_rate_error, new_portfolio, new_payment_dates

@app.callback(
        [Output('optimizer_no','style'),
         Output('optimizer_yes','style')],
         [Input('input-use_of_optimizer','value')]
        )
def use_of_optimizer(optim):
    if optim == 'Yes':
        return dict(display='none'), dict()
    return dict(), dict(display='none')

# =============================================================================
# Optimizer
# =============================================================================

@app.callback(
    [Output('output-num_Max_HY', 'children'),
     Output('output-max_sector_weight', 'children'),
     Output('output-max_country_weight', 'children'),
     Output('output-bonds_maturity', 'children'),
     Output('output-max_issuer_weight_IG', 'children'),
     Output('output-max_issuer_weight_HY', 'children'),
     Output('output-max_ISIN_weight', 'children'),
     Output('output-Max_SumWeight','children'),

     Output('store-constraints','data')
     ],

    [Input('input-num_Max_HY', 'value'),
     Input('input-max_sector_weight', 'value'),
     Input('input-max_country_weight', 'value'),
     Input('input-bonds_maturity_start', 'value'),
     Input('input-bonds_maturity_end', 'value'),
     Input('input-max_issuer_weight_IG', 'value'),
     Input('input-max_issuer_weight_HY', 'value'),
     Input('input-max_ISIN_weight', 'value'),
     Input('input-Max_SumWeight','value'),

     Input('input-energy_sector', 'value'),
     Input('input-senior_bonds_only', 'value'),
     Input('input-callable_bonds', 'value'),
     Input('input-greater_B3','value'),
     Input('input-bool_Reinv', 'value'),
     Input('input-bool_Default','value'),
     ]
    )
def callback_constraints_errors(num_Max_HY, max_sector_weight, max_country_weight, bonds_maturity_start,
                                bonds_maturity_end, max_issuer_weight_IG, max_issuer_weight_HY,
                                max_ISIN_weight, Max_SumWeight,
                                energy_sector, senior_bonds_only,
                                callable_bonds,
                                greater_B3, bool_Reinv, bool_Default):
    '''
    checking parameters for the contraints needed in the optimizer
    '''
    constraints = {
            "bool_B-" : (greater_B3=='Yes'),
            "bool_callable" : (callable_bonds=='Yes'),
            "bool_Energy" : (energy_sector=='Yes'),
            "bool_Senior" : (senior_bonds_only=='Yes'),
            "bool_Reinv" : (bool_Reinv=='Yes'),
            "bool_Default" : (bool_Default=='Yes'),
            }
    
    num_Max_HY_error = [fct.error(num_Max_HY)]
    if num_Max_HY_error[0] is None:
        constraints["num_Max_HY"] = fct.take_number(num_Max_HY)
    
    max_sector_weight_error = [fct.error(max_sector_weight)]
    if max_sector_weight_error[0] is None:
        constraints["num_Max_Sector"] = fct.take_number(max_sector_weight)

    max_country_weight_error = [fct.error(max_country_weight)]
    if max_country_weight_error[0] is None:
        constraints["num_Max_Country"] = fct.take_number(max_country_weight)

    max_issuer_weight_IG_error = [fct.error(max_issuer_weight_IG)]
    if max_issuer_weight_IG_error[0] is None:
        constraints["num_Max_Issuers_IG"] = fct.take_number(max_issuer_weight_IG)
    
    max_issuer_weight_HY_error = [fct.error(max_issuer_weight_HY)]
    if max_issuer_weight_HY_error[0] is None:
        constraints["num_Max_Issuers_HY"] = fct.take_number(max_issuer_weight_HY)

    max_ISIN_weight_error = [fct.error(max_ISIN_weight)]
    if max_ISIN_weight_error[0] is None:
        constraints["num_Max_Isin"] = fct.take_number(max_ISIN_weight)

    Max_SumWeight_error = [fct.error(Max_SumWeight)]
    if Max_SumWeight_error[0] is None:
        constraints["num_Max_SumWeight"] = fct.take_number(Max_SumWeight)

    bonds_maturity = [None]

    if bonds_maturity_start is None or bonds_maturity_end is None or bonds_maturity_start > bonds_maturity_end:
        bonds_maturity = [
                dcc.Markdown(
                        children = '''The selected input has not the good format: starting year greater than ending year''',
                        style = {'textAlign': 'center',
                                 'color': colors['error'],
                                 'backgroundColor' : colors['background_error']
                                 })
        ]
    else:
        constraints["num_Start_Date"] = bonds_maturity_start
        constraints["num_End_Date"] = bonds_maturity_end


    return (num_Max_HY_error, max_sector_weight_error, max_country_weight_error,
            bonds_maturity, max_issuer_weight_IG_error, max_issuer_weight_HY_error,
            max_ISIN_weight_error,
            Max_SumWeight_error,
            constraints)

@app.callback(
    Output('store-uploaded-list_tickers', 'data'),
    [
     Input('upload-list_tickers', 'contents'),
    ],
    [
     State('upload-list_tickers', 'filename'),]
    )

def list_tickers_parsing(list_tickers, list_tickers_name):
    if list_tickers is not None:
        list_tickers = fct.parse_contents(list_tickers, list_tickers_name, 'list_tickers')
        list_tickers = list_tickers.to_dict('records')
    else:
        list_tickers = None
    return list_tickers

@app.callback(
    [
     Output('uploaded_list_tickers', 'columns'),
     Output('uploaded_list_tickers', 'style_header'),
     Output('uploaded_list_tickers', 'style_cell'),
     Output('adding-rows-button-list_tickers', 'style'),
     ],
    [Input('store-uploaded-list_tickers', 'data')],
    [
     State('uploaded_list_tickers', 'data'),
     State('uploaded_list_tickers', 'columns'),
    ]
    )

def list_tickers_editing(stored_port,
                      uploaded_list_tickers, columns):
    '''
    we are forced to split the callback function between columns and all the other parameter of style
    and the one about data to integrate changes of row and parameters in the dataframe
    '''
    if stored_port is not None :

        if uploaded_list_tickers is None:
            stored_port = pd.DataFrame(stored_port)
            
            columns = [{'name': i,
                        'id': i,
                        'deletable': True,
                        'renamable': True } for i in stored_port.columns]
        style_header={
                'backgroundColor': colors['background_boxes'],
                'textAlign': 'center',
                'color': 'white',
                'fontWeight': 'bold'
                }
        style_cell={
                'textAlign': 'center',
                'height': 'auto',
                }

        adding_button = dict()

        return columns, style_header, style_cell, adding_button
    return [], {}, {}, dict(display='none')

@app.callback(
     Output('uploaded_list_tickers', 'data'),

    [Input('store-uploaded-list_tickers', 'data'),
     Input('adding-rows-button-list_tickers', 'n_clicks'),
     ],
    [
     State('uploaded_list_tickers', 'columns'),
     State('uploaded_list_tickers', 'data'),
     ]
    )

def list_tickers_editing_data(stored_list_tickers, n_clicks_adding_rows,
                           columns, uploaded_list_tickers):
    '''
    once the buttons of adding_rows and adding_columns are pressed here is where
    we modify the list_tickers - dataframe
    '''
    if stored_list_tickers is not None :
        if uploaded_list_tickers is not None:
            data = pd.DataFrame(uploaded_list_tickers)
        else:
            data = pd.DataFrame(stored_list_tickers)
        # modifying rows
        if n_clicks_adding_rows > 0:
            data.append({c['id']: '' for c in columns}, ignore_index=True)

        return data.to_dict('records')
    return None

@app.callback(
    Output('store-list_tickers_modified', 'data'),
    [Input('uploaded_list_tickers','data'),
     Input('uploaded_list_tickers','columns')],
    )

def store_list_tickers(list_tickers, columns):
    if list_tickers is not None:
        list_tickers = pd.DataFrame(list_tickers)
        list_tickers.columns = pd.DataFrame(columns).name
        list_tickers = list_tickers.to_dict('records')
        return list_tickers
    return None

   
@app.callback(
        Output('button-parsing_universe', 'style'),
        [Input('output-max_sector_weight', 'children'),
         Input('output-max_country_weight', 'children'),
         Input('output-bonds_maturity', 'children'),
         Input('output-max_issuer_weight_IG', 'children'),
         Input('output-max_issuer_weight_HY', 'children'),
         Input('output-max_ISIN_weight', 'children'),
         Input('output-Max_SumWeight','children'),
         Input('output-recovery_rate', 'children'),
         Input('output-reinvest_rate', 'children'),
         Input('store-list_tickers_modified', 'data')
         ])

def showing_button_parsing_universe(max_sector_weight, max_country_weight, bonds_maturity,
                                    max_issuer_weight_IG, max_issuer_weight_HY, max_ISIN_weight,
                                    Max_SumWeight,
                                    recovery_rate_error, reinvest_rate_error, list_tickers):
    checks = np.array([
            #if the only element of these lists is None, then the parameter has the good format
            max_sector_weight[0] is None ,
            max_country_weight[0] is None ,
            bonds_maturity[0] is None ,
            max_issuer_weight_IG[0] is None ,
            max_issuer_weight_HY[0] is None ,
            max_ISIN_weight[0] is None ,
            Max_SumWeight[0] is None ,
            recovery_rate_error[0] is None ,
            reinvest_rate_error[0] is None ,
            list_tickers is not None
            ])
    if checks.all():
        return {
                'width': '250px',
                'height': '60px',
                'lineHeight': '60px',
                'borderWidth': '2px',
                'borderStyle': 'outset',
                'borderRadius': '5px',
                'textAlign': 'center',
                'margin': '10px',
                'backgroundColor': colors['title'],
                'color': 'white',
                'vertical-align': 'middle',
                'fontSize':15,
                }
    return dict(display='none')



@app.callback(
    Output('store-uploaded-universe', 'data'),
    [Input('button-parsing_universe', 'n_clicks'),
     Input('input-bbg_xla', 'value'),
     Input('input-bbg_dll', 'value'),
     Input('store-list_tickers_modified', 'data')],
    [State('store-constraints','data')
     ],
    )

def launch_parsing_universe(n_clicks,
                            bbg_xla, bbg_dll, list_tickers, constraints):
    if n_clicks > 0:
        list_tickers = pd.DataFrame(list_tickers)
#        import pdb; pdb.set_trace()
        df = parsing_universe(constraints, bbg_xla, bbg_dll, list_tickers['tickers'], 'EUR')
        return df.to_dict('records')
    return None

#@app.callback(
#    Output('store-uploaded-universe', 'data'),
#    [
#     Input('upload-universe', 'contents'),
#    ],
#    [
#     State('upload-universe', 'filename'),]
#    )
#
#def universe_parsing(universe, universe_name):
#    if universe is not None:
#        new_universe = fct.parse_contents(universe, universe_name, 2)
#        new_universe = new_universe.to_dict('records')
#    else:
#        new_universe = None
#    return new_universe

@app.callback(
    [
     Output('uploaded_universe', 'columns'),
     Output('uploaded_universe', 'style_header'),
     Output('uploaded_universe', 'style_cell'),
     Output('adding-rows-button-universe', 'style'),
     Output('adding-columns-button-universe', 'style'),
     Output('adding-columns-name-universe', 'style')
     ],
    [Input('store-uploaded-universe', 'data'),
     Input('adding-columns-button-universe', 'n_clicks')],
    [
     State('uploaded_universe', 'data'),
     State('uploaded_universe', 'columns'),
     State('adding-columns-name-universe', 'value'),]
    )

def universe_editing(stored_uni,n_clicks_adding_columns,
                      uploaded_universe, columns, column_name):
    '''
    we are forced to split the callback function between columns and all the other parameter of style
    and the one about data to integrate changes of row and parameters in the dataframe
    '''
    if stored_uni is not None :

        if uploaded_universe is None:
            stored_uni = pd.DataFrame(stored_uni)
            columns = []
            stored_uni.Maturity = show_correct_datetime(stored_uni.Maturity)
            for col in stored_uni.columns:
                if col == 'AskYTW' :
                    columns += [{'name': col,
                                 'id': col,
                                 'deletable': True,
                                 'renamable': True,
                                 'type': 'numeric',
                                 'format': Format(
                                         scheme=Scheme.fixed,
                                         precision=2,
                                         )}]
                else:
                    columns += [{'name': col,
                                 'id': col,
                                 'deletable': True,
                                 'renamable': True }]
        style_header={
                'backgroundColor': colors['background_boxes'],
                'textAlign': 'center',
                'color': 'white',
                'fontWeight': 'bold'
                }
        style_cell={
                'textAlign': 'center',
                'height': 'auto',
                }


        # modifying columns
        if n_clicks_adding_columns > 0:
            columns.append({
                    'id': column_name, 'name': column_name,
                    'renamable': True, 'deletable': True
                })
        editing_button = dict()
        adding_button = dict()
        style_add_col_name = {'padding': 10}

        return columns, style_header, style_cell, editing_button, adding_button, style_add_col_name
    return [], {}, {}, dict(display='none'), dict(display='none'), dict(display='none')

@app.callback(
     Output('uploaded_universe', 'data'),

    [Input('store-uploaded-universe', 'data'),
     Input('adding-rows-button-universe', 'n_clicks'),
     Input('adding-columns-button-universe', 'n_clicks'),
     ],
    [
     State('uploaded_universe', 'columns'),
     State('uploaded_universe', 'data'),
     State('adding-columns-name-universe', 'value')
     ]
    )

def universe_editing_data(stored_uni, n_clicks_adding_rows, 
                           n_clicks_adding_columns,
                           columns, uploaded_universe, column_name):
    '''
    once the buttons of adding_rows and adding_columns are pressed here is where
    we modify the universe - dataframe
    '''
    if stored_uni is not None :
        if uploaded_universe is not None:
            data = pd.DataFrame(uploaded_universe)
        else:
            data = pd.DataFrame(stored_uni)
        data.Maturity = show_correct_datetime(data.Maturity)
        # modifying rows
        if n_clicks_adding_rows > 0:
            data.append({c['id']: '' for c in columns}, ignore_index=True)

        # modifying columns
        if n_clicks_adding_columns > 0:
            data[column_name] = ''

        return data.to_dict('records')
    return None

@app.callback(
    Output('store-universe_modified', 'data'),
    [Input('uploaded_universe','data'),
     Input('uploaded_universe','columns')],
    )

def store_universe(universe, columns):
    if universe is not None:
        universe = pd.DataFrame(universe)
        universe.columns = pd.DataFrame(columns).name
        universe = universe.to_dict('records')
        return universe
    return None


@app.callback(
    Output('button-launch-optimizer', 'style'),
    [Input('store-universe_modified','data'),

     Input('output-max_sector_weight', 'children'),
     Input('output-max_country_weight', 'children'),
     Input('output-bonds_maturity', 'children'),
     Input('output-max_issuer_weight_IG', 'children'),
     Input('output-max_issuer_weight_HY', 'children'),
     Input('output-max_ISIN_weight', 'children'),
     Input('output-Max_SumWeight','children'),
     Input('output-recovery_rate', 'children'),
     Input('output-reinvest_rate', 'children'),
     ],
    )

def launch_optim_activation(universe, max_sector_weight, max_country_weight, bonds_maturity,
                            max_issuer_weight_IG, max_issuer_weight_HY, max_ISIN_weight, Max_SumWeight,
                            recovery_rate_error, reinvest_rate_error):
    '''
    to make the button appear we need that all the check are void
    '''
    checks = np.array([
            #if the only element of these lists is None, then the parameter has the good format
            max_sector_weight[0] is None ,
            max_country_weight[0] is None ,
            bonds_maturity[0] is None ,
            max_issuer_weight_IG[0] is None ,
            max_issuer_weight_HY[0] is None ,
            max_ISIN_weight[0] is None ,
            Max_SumWeight[0] is None ,
            recovery_rate_error[0] is None ,
            reinvest_rate_error[0] is None
            ])
    if universe is not None: #if no universe uploaded no need to make things work
        if checks.all():
            return {
                    'width': '250px',
                    'height': '60px',
                    'lineHeight': '60px',
                    'borderWidth': '2px',
                    'borderStyle': 'outset',
                    'borderRadius': '5px',
                    'textAlign': 'center',
                    'margin': '10px',
                    'backgroundColor': colors['background_boxes'],
                    'color': 'white',
                    'vertical-align': 'middle',
                    'fontSize':15,
                    }
    return dict(display='none')

@app.callback(
    [Output('table-optimizer', 'data'),
     Output('table-optimizer', 'columns'),
     Output('table-optimizer', 'style_header'),
     Output('table-optimizer', 'style_cell'),
     Output('name-table-optimizer','style'),
     Output('markdown-paym_dates-optim','children')
     ],
    [Input('button-launch-optimizer', 'n_clicks')],
    [State('store-universe_modified','data'),

     State('store-constraints','data'),

     State('input-cncy', 'value'),
     State("input-recovery_rate",'value'),
     State('input-reinvest_rate', 'value'),
     State('input-bonds_maturity_end','value')
     ],
    )

def launch_optim(n_clicks,
                 universe, constraints,
                 currency_fund, recovery_rate, reinvest_rate, ending_year):
    '''
    to make the button appear we need that all the check are void
    '''

    if universe is not None and n_clicks > 0 : #if no universe uploaded no need to make things work
        universe = pd.DataFrame(universe)
        threshold = 0.0005
        recovery_rate = fct.take_number(recovery_rate)
        reinvest_rate = fct.take_number(reinvest_rate)
        
        #definition of the swap rates by currency and maturity
        currency_issues = list(universe.CRNCY.unique())
        currency_issues.append(currency_fund)
        currency_issues = list(set(currency_issues))
        df_swap_rates = df_swap_rates_func(True, currency_issues, folder)

        Portfolio = qrg_api.fct_optimizer(universe, constraints, reinvest_rate, recovery_rate,
                                          df_swap_rates, currency_fund, folder)
#        Portfolio = optimizer(universe, constraints, reinvest_rate, recovery_rate, folder)
        Portfolio = Portfolio[ Portfolio.Weight >= threshold ]
        
        columns = []
        for col in Portfolio.columns:
            if col in ['Weight']:
                columns += [{'name': col,
                             'id': col,
                             'type': 'numeric',
                             'format': Format(
                                        scheme=Scheme.fixed,
                                        precision=3,
                                        )}]
            else:
                columns += [{'name': col,
                             'id': col}]
                
        style_header={
                'backgroundColor': colors['background_boxes'],
                'textAlign': 'center',
                'color': 'white',
                'fontWeight': 'bold'
                }
        style_cell={
                'textAlign': 'center',
                'height': 'auto',
                }
        
        style_name_result = {
                'textAlign': 'left',
                'color': colors['subtitle']
                }

        markdown_paym_dates = 'The coupon payment and the notional payment in the yields computation is supposed to be done the 31-12-{}'.format(ending_year)

        return [Portfolio.to_dict('records'), columns, style_header, style_cell,
                style_name_result, markdown_paym_dates]
    return None, [], {}, {}, dict( display= 'none'), ''


# =============================================================================
# Portfolio modifications
# =============================================================================
# showing actual portfolio downloaded
@app.callback(
    [
     Output('uploaded_portfolio-to_screen', 'columns'),
     Output('uploaded_portfolio-to_screen', 'style_header'),
     Output('uploaded_portfolio-to_screen', 'style_cell'),
     Output('adding-rows-button-portfolio', 'style'),
     Output('adding-columns-button-portfolio', 'style'),
     Output('adding-columns-name-portfolio', 'style')
     ],
    [Input('store-uploaded-portfolio', 'data'),
     Input('adding-columns-button-portfolio', 'n_clicks')],
    [
     State('uploaded_portfolio-to_screen', 'data'),
     State('uploaded_portfolio-to_screen', 'columns'),
     State('adding-columns-name-portfolio', 'value'),]
    )

def portfolio_editing(stored_port,n_clicks_adding_columns,
                      uploaded_portfolio, columns, column_name):
    '''
    we are forced to split the callback function between columns and all the other parameter of style
    and the one about data to integrate changes of row and parameters in the dataframe
    '''
    if stored_port is not None :

        if uploaded_portfolio is None:
            stored_port = pd.DataFrame(stored_port)
            columns = [{'name': i,
                        'id': i,
                        'deletable': True,
                        'renamable': True } for i in stored_port.columns]
        style_header={
                'backgroundColor': colors['background_boxes'],
                'textAlign': 'center',
                'color': 'white',
                'fontWeight': 'bold'
                }
        style_cell={
                'textAlign': 'center',
                'height': 'auto',
                }


        # modifying columns
        if n_clicks_adding_columns > 0:
            columns.append({
                    'id': column_name, 'name': column_name,
                    'renamable': True, 'deletable': True
                })
        editing_button = dict()
        adding_button = dict()
        style_add_col_name = {'padding': 10}

        return columns, style_header, style_cell, editing_button, adding_button, style_add_col_name
    return [], {}, {}, dict(display='none'), dict(display='none'), dict(display='none')

@app.callback(
     Output('uploaded_portfolio-to_screen', 'data'),

    [Input('store-uploaded-portfolio', 'data'),
     Input('adding-rows-button-portfolio', 'n_clicks'),
     Input('uploaded_portfolio-to_screen', 'columns'),
     Input('adding-columns-button-portfolio', 'n_clicks'),
     ],
    [
     State('uploaded_portfolio-to_screen', 'data'),
     State('adding-columns-name-portfolio', 'value')
     ]
    )

def portfolio_editing_data(stored_port, n_clicks_adding_rows, columns,
                           n_clicks_adding_columns, uploaded_portfolio, column_name):
    '''
    once the buttons of adding_rows and adding_columns are pressed here is where
    we modify the portfolio - dataframe
    '''
    if stored_port is not None :
        if uploaded_portfolio is not None:
            data = pd.DataFrame(uploaded_portfolio)
        else:
            data = pd.DataFrame(stored_port)
        # modifying rows
        if n_clicks_adding_rows > 0:
            data.append({c['id']: '' for c in columns}, ignore_index=True)

        # modifying columns
        if n_clicks_adding_columns > 0:
            data[column_name] = ''

        return data.to_dict('records')
    return None

@app.callback(
    [Output('error_messages_portfolio', 'children'),
     Output('correct_input_portfolio','data')],
    [Input('uploaded_portfolio-to_screen','data'),
     Input('uploaded_portfolio-to_screen','columns')],
    )

def error_messages_portfolio(stored_port, columns):
    '''
    check on the good format of the portfolio in order to be correctly treated by the function buy_and_hold_analysis
    '''

    children = []
    message_ISIN = '''
    No column named "ISIN". Please modify manually.
    '''
    message_Weight = '''
    No column named "Weight" has been detected. Rename the weights' column as "Weight" or the portfolio will be considerated by default as equiweighted.
    '''
    if stored_port is not None:
        stored_port = pd.DataFrame(stored_port)
        columns = pd.DataFrame(columns)
        flag_error = 0

        if 'Weight' not in pd.DataFrame(columns).name.values :
            children += [dcc.Markdown(
                    children = message_Weight,
                    style = {'textAlign': 'center',
                             'color': colors['error'],
                             'backgroundColor' : colors['background_error']
                             })]
        else:
            Weight_id = columns['id']['Weight' == columns['name']]
            Weight = stored_port[Weight_id]

            try:
                Weight.astype(np.float64)
            except:
                children += [dcc.Markdown(
                    children = '''The Weight's column has not a good format.
                                Please modify manually or import another dataframe.''',
                    style = {'textAlign': 'center',
                             'color': colors['error'],
                             'backgroundColor' : colors['background_error']
                             })]
                flag_error = 1
        # when no header is given
        if 'ISIN' not in pd.DataFrame(columns).name.values :
            children = [dcc.Markdown(
                    children = message_ISIN,
                    style = {'textAlign': 'center',
                             'color': colors['error'],
                             'backgroundColor' : colors['background_error']
                             })]+children
            flag_error = 1

        if flag_error == 0:
            stored_port.columns = pd.DataFrame(columns).name
            stored_port = stored_port.to_dict('records')
            return children, stored_port
    return children, None

@app.callback(
        Output('button-check-portfolio', 'style'),
        [Input('correct_input_portfolio','data'),
         Input('table-optimizer','data')],
        [State("input-use_of_optimizer",'value')])
def check_portfolio_button_activation(stored_port, stored_port_optim, use_optim):
    '''
    when a portfolio with the good format is loaded we can show the button that will
    push us to Bloomerg to take the data needed for the computation
    '''
    if use_optim == 'Yes':
        stored_port = stored_port_optim
    if stored_port is not None:
        style_check_portfolio = {
                'width': '250px',
                'height': '60px',
                'lineHeight': '60px',
                'borderWidth': '2px',
                'borderStyle': 'outset',
                'borderRadius': '5px',
                'textAlign': 'center',
                'margin': '10px',
                'backgroundColor': colors['title'],
                'color': 'white',
                'vertical-align': 'middle',
                'fontSize':18,
            }
        return style_check_portfolio
    return dict(display='none')

# =============================================================================
#  NOW ONLY WE GO ON BLOOM TO PARSE THE PORTFOLIO
# =============================================================================

@app.callback(
    [Output('store-portfolio_from_bbg', 'data'),
     Output('store-rating_from_SandP', 'data'),
     Output('store-rating_from_Moodys', 'data'),
     Output('store-rating_from_Fitch', 'data'),
     Output('store-bdp_result', 'data'),
     Output('store-weight_cash', 'data')
     ],
     [Input('button-check-portfolio', 'n_clicks')],
     [
     State('correct_input_portfolio', 'data'),
     State('table-optimizer','data'),
     State("input-use_of_optimizer",'value')
     ])

def click_parse_portfolio(n_clicks, portfolio,portfolio_optim, use_optim):
    '''
    when the button parse_portfolio is pushed we go to BBG and parse the needed data
    '''
    stored_port = None
    if n_clicks > 0:
        if use_optim == 'Yes':
            portfolio = portfolio_optim

        # parsing the content first like the previous function
        if portfolio is not None :
            portfolio = pd.DataFrame(portfolio)
            stored_port, rating_from_SandP, rating_from_Moodys, rating_from_Fitch, bdp_result, weight_cash = parsing_portfolio(portfolio,
                                                                                                                               folder,
                                                                                                                               download_from_bbg=True)
            return stored_port.to_dict('records'), rating_from_SandP, rating_from_Moodys, rating_from_Fitch, bdp_result.to_dict('records'), weight_cash
    return stored_port, [],[],[], None, 0.

   
stored_port = pd.read_csv('Z:/Users/Antonio/FI_BnH/portfolio_fromBBG.csv', index_col =0)  
@app.callback(
    [
     Output('table-portfolio_after_bbg', 'data'),
     Output('table-portfolio_after_bbg', 'columns'),
     Output('table-portfolio_after_bbg', 'style_header'),
     Output('table-portfolio_after_bbg', 'style_cell')
     ],
    [Input('store-portfolio_from_bbg', 'data')],
    )

def table_editing(stored_port):
    """
    after having parsed the data, we need to change these fields in order to
    """
    if stored_port is not None :
        stored_port = pd.DataFrame(stored_port)
        if 'MATURITY' in stored_port.columns:
            stored_port['MATURITY'] = show_correct_datetime(stored_port['MATURITY'])
        data = stored_port.to_dict('records')
        columns = []
        for col in stored_port.columns:
            if col in ['Weight']:
                columns += [{'name': col,
                             'id': col,
                             'type': 'numeric',
                             'format': Format(
                                        scheme=Scheme.fixed,
                                        precision=3,
                                        )}]
            elif col in ["PX_DIRTY_ASK", "YLD_CNV_ASK", 'YAS_BOND_YLD']:
                columns += [{'name': col,
                             'id': col,
                             'type': 'numeric',
                             'format': Format(
                                        scheme=Scheme.fixed,
                                        precision=2,
                                        )}]
            else:
                columns += [{'name': col,
                             'id': col}]
        
        style_header={
                'backgroundColor': colors['background_boxes'],
                'textAlign': 'center',
                'color': 'white',
                'fontWeight': 'bold'
                }
        style_cell={
                'textAlign': 'center',
                'height': 'auto',
                }

        return data, columns, style_header, style_cell
    return None, [], {}, {}

#@app.callback()

@app.callback(
     [Output('table-portfolio_after_bbg', 'style_data_conditional'),
      Output('legend_rating_selection', 'children'),
      Output('labels', 'children')],

     [Input('table-portfolio_after_bbg', 'data')],
     [
      State('store-rating_from_SandP', 'data'),
      State('store-rating_from_Moodys', 'data'),
      State('store-rating_from_Fitch', 'data'),
      State('store-bdp_result', 'data')
     ])
def modified_highlights(stored_port, rating_from_SandP, rating_from_Moodys, rating_from_Fitch, bdp_result):
    '''
    change in the colors of certain cells of the portfolio if error in data collection or
    to explain how NR rating have been changed
    '''
    children_labels = []
    if stored_port is not None :
        stored_port = pd.DataFrame(stored_port)

        good_ratings = np.array(['AAA','AA','A','BBB','BB','B','CCC'])
        bad_ratings_ISIN = stored_port.ISIN[~stored_port.BB_COMPOSITE.isin(good_ratings)]

        legend = ''


        style_data_conditional = [
                # negative yields
                {
                        'if': {'filter_query': '{YLD_CNV_ASK} < 0',
                               'column_id': 'YLD_CNV_ASK' },
                        'textAlign': 'center',
                        'backgroundColor': colors['neg_yields']
                }
                ]+[
                # price above 200
                {
                        'if': {'filter_query': '{PX_DIRTY_ASK} > 200',
                               'column_id': 'PX_DIRTY_ASK' },
                        'textAlign': 'center',
                        'backgroundColor': colors['price>200']
                }
                ]+[
#                                    {
#                                        'if': {'columns' : 'BB_COMPOSITE', 'row_index': 'odd'},
#                                        'textAlign': 'center',
#                                        'backgroundColor': 'rgb(248, 248, 248)'
#                                    }]+[
                # coloring ratings from S&P's
                {
                        'if': {'filter_query': '{{ISIN}} = {}'.format(isin),
                               'column_id': 'BB_COMPOSITE' },
                        'textAlign': 'center',
                        'backgroundColor': colors['S&P']
                } for isin in rating_from_SandP
                ]+[
                # coloring ratings from Moody's
                {
                        'if': {'filter_query': '{{ISIN}} = {}'.format(isin),
                               'column_id': 'BB_COMPOSITE' },
                        'textAlign': 'center',
                        'backgroundColor': colors['Moodys']
                } for isin in rating_from_Moodys
                ]+[
                # coloring ratings from Fitch
                {
                        'if': {'filter_query': '{{ISIN}} = {}'.format(isin),
                               'column_id': 'BB_COMPOSITE' },
                        'textAlign': 'center',
                        'backgroundColor': colors['Fitch']
                } for isin in rating_from_Fitch
                ]+[
                # coloring no rating found
                {
                        'if': {'filter_query' : '{{ISIN}} = {}'.format(ISIN),
                               'column_id': 'BB_COMPOSITE' },
                        'textAlign': 'center',
                        'backgroundColor': colors['no_rating']
                    } for ISIN in bad_ratings_ISIN
                ]
        if len(rating_from_SandP) > 0 or len(rating_from_Moodys) > 0 or len(rating_from_Fitch) > 0 or len(bad_ratings_ISIN) > 0 :
            legend = legend_rating_selection
        if len(rating_from_SandP) > 0:
            children_labels += [
                    daq.Indicator(
                            label="S&P's rating",
                            labelPosition="right",
                            value = True,
                            width=16,
                            height=16,
                            color=colors['S&P'],
                    )]
        if len(rating_from_Moodys) > 0:
            children_labels += [
                    daq.Indicator(
                            label="Moody's rating",
                            labelPosition="right",
                            value = True,
                            width=16,
                            height=16,
                            color=colors['Moodys'],
                    )]
        if len(rating_from_Fitch) > 0:
            children_labels += [
                    daq.Indicator(
                            label="Fitch's rating",
                            labelPosition="right",
                            value = True,
                            width=16,
                            height=16,
                            color=colors['Fitch'],
                    )]
        stored_port.YLD_CNV_ASK = pd.to_numeric(stored_port.YLD_CNV_ASK)
        if (stored_port.YLD_CNV_ASK < 0).any() :
            children_labels += [
                    daq.Indicator(
                            label="Negative yields",
                            labelPosition="right",
                            value = True,
                            width=16,
                            height=16,
                            color=colors['neg_yields'],
                    )]
        stored_port.PX_DIRTY_ASK = pd.to_numeric(stored_port.PX_DIRTY_ASK)
        if len(bad_ratings_ISIN) > 0 or (stored_port.PX_DIRTY_ASK > 200).any():
            legend += '\nERROR :\n'
        if len(bad_ratings_ISIN) > 0 :
            legend += 'No rating available for some bonds, change before computing yields \n'
            legend += '(look in Bloomberg for rating or remove these bonds from the portfolio)\n'
            children_labels += [
                    daq.Indicator(
                            label="No rating available",
                            labelPosition="right",
                            value = True,
                            width=16,
                            height=16,
                            color=colors['no_rating'],
                    )]

        if (stored_port.PX_DIRTY_ASK > 200).any():
            legend += 'One or more bonds\' price is above 200\n'
            children_labels += [
                    daq.Indicator(
                            label="Price above 200",
                            labelPosition="right",
                            value = True,
                            width=16,
                            height=16,
                            color=colors['price>200'],
                    )]

        return style_data_conditional, legend, children_labels
    return [], '', children_labels

@app.callback(
        Output('store-portfolio_modified', 'data'),
        [Input('table-portfolio_after_bbg', 'data')])

def good_portfolio_to_run(stored_port):
    '''
    only once all the error messages have been solved on the portfolio we can proceed in the computation of the yields
    '''
    if stored_port is not None :
        stored_port = pd.DataFrame(stored_port)
        good_ratings = np.array(['AAA','AA','A','BBB','BB','B','CCC'])
        bad_ratings_ISIN = stored_port.ISIN[~stored_port.BB_COMPOSITE.isin(good_ratings)]
        if len(bad_ratings_ISIN) == 0 :
            return stored_port.to_dict('records')
    return None




# =============================================================================
# Payment dates modifications
# =============================================================================


@app.callback(
        [Output('coupon-hide-starting-date-cell','hidden'),
         Output('coupon-hide-frequency-cell','hidden'),

         Output('notional-hide-starting-date-cell','hidden'),
         Output('notional-hide-frequency-cell','hidden')
         ],

        [Input('unique_value-coupon','value'),
         Input('input-coupon-starting_date','value'),
         Input('input-coupon-ending_date','value'),

         Input('unique_value-notional','value'),
         Input('input-notional-starting_date','value'),
         Input('input-notional-ending_date','value')
         ]
        )
def show_starting_date_n_frequency(value_coupon,starting_date_coupon,ending_date_coupon,
                                   value_notional,starting_date_notional,ending_date_notional):
    '''
    showing field starting_date and frequency only when needed
    '''

    if value_coupon=='Yes':
        coupon = True,True
    else:
        try:
            starting_date_coupon = pd.to_datetime([starting_date_coupon])
            ending_date_coupon = pd.to_datetime([ending_date_coupon])
            if starting_date_coupon == ending_date_coupon:
                coupon = False, True
            else:
                coupon = False, False
        except:
            coupon = False, False


    if value_notional=='Yes':
        notional = True,True
    else:
        try:
            starting_date_notional = pd.to_datetime([starting_date_notional])
            ending_date_notional = pd.to_datetime([ending_date_notional])
            if starting_date_notional == ending_date_notional:
                notional = False, True
            else:
                notional = False, False
        except:
            notional = False, False


    return coupon + notional


@app.callback(
         Output('coupon-hide-max_maturity-cell','hidden'),
        [Input('store-portfolio_modified', 'data')]
        )
def show_max_maturity_coupon(stored_port):
    if stored_port is not None:
        return False
    return True

@app.callback(
         Output('notional-hide-max_maturity-cell','hidden'),
        [Input('store-portfolio_modified', 'data')]
        )
def show_max_maturity_notional(stored_port):
    if stored_port is not None:
        return False
    return True

@app.callback(
        [
         Output('input-coupon-ending_date','value'),
         Output('input-notional-ending_date','value'),
         ],
        [Input('store-portfolio_modified', 'data'),
         Input('coupon-max_maturity-ending_date','value'),
         Input('notional-max_maturity-ending_date','value')
         ],
        [State('input-coupon-ending_date','value'),
         State('input-notional-ending_date','value')]
        )
def using_max_maturity(stored_port, using_max_mat_coupon, using_max_mat_notional,
                       ending_time_coupon, ending_time_notional):
    if stored_port is not None:
        if using_max_mat_coupon == 'Yes' :
            stored_port = pd.DataFrame(stored_port)
            stored_port.MATURITY = pd.to_datetime(stored_port.MATURITY)

            ending_time_coupon = max(stored_port.MATURITY)
            ending_time_coupon = str(ending_time_coupon)[:10]

        if using_max_mat_notional == 'Yes':
            stored_port = pd.DataFrame(stored_port)
            stored_port.MATURITY = pd.to_datetime(stored_port.MATURITY)

            ending_time_notional = max(stored_port.MATURITY)
            ending_time_notional = str(ending_time_notional)[:10]

    return [ ending_time_coupon, ending_time_notional ]

#taking inputs
@app.callback(
    [Output('output-coupon-starting_date', 'children'),
     Output('output-coupon-ending_date', 'children'),

     Output('output-notional-starting_date', 'children'),
     Output('output-notional-ending_date', 'children'),

     Output('output-error-payment_build', 'children'),

     Output('store-fromconstructor-payment_dates',"data")
     ],

    [Input('button-build_payment_dates', 'n_clicks')
     ],

     [State('unique_value-coupon','value'),
     State('input-coupon-starting_date', 'value'),
     State('input-coupon-ending_date', 'value'),
     State('input-coupon-frequency', 'value'),
     State('adding-coupon-ending_date', 'value'),

     State('unique_value-notional','value'),
     State('input-notional-starting_date', 'value'),
     State('input-notional-ending_date', 'value'),
     State('input-notional-frequency', 'value'),
     State('adding-notional-ending_date', 'value'),

     State('store-fromconstructor-payment_dates',"data")
     ]
    )

def callback_build_payment(n_clicks,
                           unique_coupon, starting_date_coupon, ending_date_coupon, freq_coupon, add_end_coupon,
                           unique_notional, starting_date_notional, ending_date_notional,freq_notional, add_end_notional,
                           payment_dates):
    '''
    check the inserted parametres for the payment dates dataframe and build the dataframe from the parameters
    '''

    starting_date_coupon_error = [fct.error_date(starting_date_coupon)]
    ending_date_coupon_error = [fct.error_date(ending_date_coupon)]

    starting_date_notional_error = [fct.error_date(starting_date_notional)]
    ending_date_notional_error = [fct.error_date(ending_date_notional)]
    error_payment_build = None

    if n_clicks > 0 :
        #if the previous check are not void but we have a problem therefore we must not continue
        if ( starting_date_coupon_error[0] is not None or ending_date_coupon_error[0] is not None  or
            starting_date_notional_error[0] is not None or ending_date_notional_error[0] is not None ):

            error_payment_build = dcc.Markdown(
                    children = '''The given inputs are not in the good format.''',
                    style = {'textAlign': 'center',
                             'color': colors['error'],
                             'backgroundColor' : colors['background_error']
                             })

        else:
            # if all the previous checks are OKAY we can build the payment dates dataframe
            # and save it in the store

            #coupon part
            if unique_coupon == 'Yes':
                coupon = [pd.to_datetime(ending_date_coupon)]
            elif pd.to_datetime(starting_date_coupon) == pd.to_datetime(ending_date_coupon):
                coupon = [pd.to_datetime(ending_date_coupon)]
            elif freq_coupon == 'Manual modification':
                coupon = pd.to_datetime([starting_date_coupon, ending_date_coupon])
            else:
                last_day_previous_year = str(asof_date.year-1)+'-12-31'
                coupon = pd.date_range(last_day_previous_year, ending_date_coupon ,
                                       freq = freq_coupon)
                coupon = coupon[ coupon > starting_date_coupon ]
                if add_end_coupon == 'Yes' and ending_date_coupon not in coupon:
                    coupon = coupon.insert(loc = len(coupon), item = pd.to_datetime(ending_date_coupon))

            coupon = pd.DataFrame(coupon, columns=['Coupon Payment Dates'])

            #notional part
            if unique_notional == 'Yes':
                notional = [pd.to_datetime(ending_date_notional)]
            elif pd.to_datetime(starting_date_notional) == pd.to_datetime(ending_date_notional):
                notional = [pd.to_datetime(ending_date_notional)]
            elif freq_notional == 'Manual modification':
                notional = pd.to_datetime([starting_date_notional, ending_date_notional])
            else:
                last_day_previous_year = str(asof_date.year-1)+'-12-31'
                notional = pd.date_range(last_day_previous_year, ending_date_notional ,
                                       freq = freq_notional)
                notional = notional[ notional > starting_date_notional ]
                if add_end_notional == 'Yes' and ending_date_notional not in notional:
                    notional = notional.insert(loc = len(notional), item = pd.to_datetime(ending_date_notional))

            notional = pd.DataFrame(notional, columns=['Notional Payment Dates'])

            payment_dates = pd.concat([coupon, notional], axis = 1)
            if len(coupon) > len(notional):
                payment_dates['Notional Payment Dates'][len(notional):] = np.nan
            elif len(coupon) < len(notional):
                payment_dates['Coupon Payment Dates'][len(coupon):] = np.nan
            payment_dates = payment_dates.to_dict('records')


    return [starting_date_coupon_error, ending_date_coupon_error,
            starting_date_notional_error, ending_date_notional_error,
            error_payment_build, payment_dates]



# showing actual Payment dates downloaded
@app.callback(
    [
     Output('uploaded_payment_dates', 'columns'),
     Output('uploaded_payment_dates', 'style_header'),
     Output('uploaded_payment_dates', 'style_cell'),
     Output('adding-rows-button-payment_dates', 'style'),
     Output('adding-columns-button-payment_dates', 'style'),
     Output('adding-columns-name-payment_dates', 'style')
     ],
    [Input('store-uploaded-payment_dates', 'data'),
     Input('store-fromconstructor-payment_dates',"data"),
     Input('store-uploaded-payment_dates', 'modified_timestamp'),
     Input('store-fromconstructor-payment_dates', 'modified_timestamp'),
     Input('adding-columns-button-payment_dates', 'n_clicks'),
     ],
    [
     State('uploaded_payment_dates', 'data'),
     State('uploaded_payment_dates', 'columns'),
     State('adding-columns-name-payment_dates', 'value'),
     ]
    )

def paym_dates_editing(stored_paym_dates,stored_paym_dates_from_builder,
                       time_paym_upload, time_paym_builder,
                       n_clicks_adding_columns,
                       
                       uploaded_paym_dates, columns, column_name
                       ):

    time_paym_upload_int = int(time_paym_upload or 0)
    time_paym_builder_int = int(time_paym_builder or 0)
    time_list = [time_paym_upload_int, time_paym_builder_int]
    stored_paym_list = [stored_paym_dates, stored_paym_dates_from_builder]
    if np.max(time_list) != 0:
        stored_paym_dates = stored_paym_list[np.argmax(time_list)]
#    import pdb; pdb.set_trace()
    if stored_paym_dates is not None :

        if uploaded_paym_dates is None:
            stored_paym_dates = pd.DataFrame(stored_paym_dates)
            columns = [{'name': i,
                        'id': i,
                        'deletable': True,
                        'renamable' : True} for i in stored_paym_dates.columns]
        style_header={
                'backgroundColor': colors['background_boxes'],
                'textAlign': 'center',
                'color': 'white',
                'fontWeight': 'bold'
                }
        style_cell={
                'textAlign': 'center',
                'height': 'auto',
                }
        
        # modifying columns
        if n_clicks_adding_columns > 0:
            columns.append({
                    'id': column_name, 'name': column_name,
                    'renamable': True, 'deletable': True
                })

        adding_row_button = dict()
        adding_button = dict()
        style_add_col_name = {'padding': 10}

        return [columns, style_header, style_cell, adding_row_button, adding_button,
                style_add_col_name]
    return [ [], {}, {}, dict(display='none'), dict(display='none'),
            dict(display='none')]

@app.callback(
     Output('uploaded_payment_dates', 'data'),

    [Input('store-uploaded-payment_dates', 'data'),
     Input('store-fromconstructor-payment_dates',"data"),
     Input('adding-rows-button-payment_dates', 'n_clicks'),
     Input('uploaded_payment_dates', 'columns'),
     Input('adding-columns-button-payment_dates', 'n_clicks'),
     Input('store-uploaded-payment_dates', 'modified_timestamp'),
     Input('store-fromconstructor-payment_dates', 'modified_timestamp'),
     ],
    [
     State('uploaded_payment_dates', 'data'),
     State('adding-columns-name-payment_dates', 'value'),

     ]
    )

def paym_dates_editing_data(stored_paym_dates,stored_paym_dates_from_builder, n_clicks_adding_rows, columns,
                           n_clicks_adding_columns,
                           time_paym_upload, time_paym_builder,
                           uploaded_paym_dates, column_name,
                           ):

    time_paym_upload_int = int(time_paym_upload or 0)
    time_paym_builder_int = int(time_paym_builder or 0)
    time_list = [time_paym_upload_int, time_paym_builder_int]
    stored_paym_list = [stored_paym_dates, stored_paym_dates_from_builder]
    if np.max(time_list) != 0:
        stored_paym_dates = stored_paym_list[np.argmax(time_list)]

    if stored_paym_dates is not None :
        ## THE PROBLEM IS HERE : UNDERSTANDING WHY THIS IF
        # if uploaded_paym_dates is not None:
        #     data = pd.DataFrame(uploaded_paym_dates)
        # else:
        data = pd.DataFrame(stored_paym_dates)

        # modifying rows
        if n_clicks_adding_rows > 0:
            data.append({c['id']: np.nan for c in columns}, ignore_index=True)

        # modifying columns
        if n_clicks_adding_columns > 0:
            data[column_name] = ''
        return data.to_dict('records')
    return None

@app.callback(
    [Output('error_messages_payment_dates', 'children'),
     Output('error_messages_payment_dates-max_maturity', 'children'),
     Output('store-payment_dates_modified', 'data')],
    [Input('uploaded_payment_dates','data'),
     Input('uploaded_payment_dates','columns'),
     Input('store-portfolio_modified','data'),
     Input('input-use_of_optimizer','value'),
     ],
     [State('input-bonds_maturity_end', 'value'),]
    )

def error_messages_paym_dates(stored_paym_dates, columns, Portfolio, use_optim_value, end_year_optim):

    children = []
    children_max_maturity = [None]
    if use_optim_value == 'Yes':
        stored_paym_dates = {'Coupon Payment Dates': ['31/12/'+str(end_year_optim)],
                                'Notional Payment Dates':['31/12/'+str(end_year_optim)]}
        columns = [{'name': i,
                        'id': i} for i in ['Coupon Payment Dates','Notional Payment Dates'] ]

    if stored_paym_dates is not None:
        stored_paym_dates = pd.DataFrame(stored_paym_dates)
        columns = pd.DataFrame(columns)
        flag_error = 0

        if use_optim_value == 'No':
            if columns.shape[0] != 2:
                children += [dcc.Markdown(
                    children = '''The number of columns is not 2, modify manually.''',
                    style = {'textAlign': 'center',
                             'color': colors['error'],
                             'backgroundColor' : colors['background_error']
                             })]
                flag_error = 1


            if not ('Coupon Payment Dates' in columns['name'].values and 'Notional Payment Dates' in columns['name'].values ):
                message = '''
                    The names of the columns are not right, they need to be "Coupon Payment Dates"
                    and "Notional Payment Dates". Please modify manually.
                    '''
                children += [dcc.Markdown(
                    children = message,
                    style = {'textAlign': 'center',
                             'color': colors['error'],
                             'backgroundColor' : colors['background_error']
                             })]
                flag_error = 1


            try:
                for col in stored_paym_dates.columns:
                    pd.to_datetime(stored_paym_dates[col])
            except:
                message = '''
                The columns are not in a goot format to be recognized as datetimes.
                Please modify manually or upload another dataframe.
                '''
                children += [dcc.Markdown(
                    children = message,
                    style = {'textAlign': 'center',
                             'color': colors['error'],
                             'backgroundColor' : colors['background_error']
                             })]
                flag_error = 1

        if (Portfolio is not None and 'Coupon Payment Dates' in columns['name'].values and
            'Notional Payment Dates' in columns['name'].values and flag_error == 0 ):
            Portfolio = pd.DataFrame(Portfolio)

            coupon_payment_dates_id = columns['id']['Coupon Payment Dates' == columns['name']].iloc[0]
            notional_payment_dates_id = columns['id']['Notional Payment Dates' == columns['name']].iloc[0]
            coupon_payment_dates,notional_payment_dates = fct.get_paym(stored_paym_dates[coupon_payment_dates_id],
                                                                      stored_paym_dates[notional_payment_dates_id])

            Maturity = pd.to_datetime(Portfolio.MATURITY)
            if (max(Maturity) > max(coupon_payment_dates) or max(Maturity) > max(notional_payment_dates) ):
                message = '''Error in payment dates : The maximum in payment dates
                    of this portfolio is greater than the maximum of Coupon payment dates or
                    Notional payment dates.'''
                children_max_maturity = [dcc.Markdown(
                    children = message,
                    style = {'textAlign': 'center',
                             'color': colors['error'],
                             'backgroundColor' : colors['background_error']
                             })]
                flag_error = 1
        # import pdb; pdb.set_trace()
        if flag_error == 0:
            stored_paym_dates.columns = pd.DataFrame(columns).name
            stored_paym_dates = stored_paym_dates.to_dict('records')
            return children,children_max_maturity, stored_paym_dates
    return children, children_max_maturity, None

@app.callback(
    [Output('super-gross-YTM', 'children'),
     Output('gross-YTM', 'children'),
     Output('estimated-gross-YTM', 'children')
     ],
     [Input('compute-yields', 'n_clicks')],
     [State('output-recovery_rate', 'children'),
      State('output-reinvest_rate', 'children'),

     State("input-recovery_rate",'value'),
     State('input-cncy', 'value'),
     State('input-reinvest_rate', 'value'),
     State('input-penalized_bonds', 'value'),

     State('store-portfolio_modified', 'data'),
     State('store-payment_dates_modified', 'data'),
     State('error_messages_payment_dates-max_maturity', 'children'),
     ])

def click_compute_yield_button(n_clicks, recovery_rate_error, reinvest_rate_error,
                               recovery_rate, cncy, reinvest_rate, penalized_bonds,
                               portfolio, payment_dates,
                               children_max_maturity):
    if n_clicks > 0:
        # parsing the content first like the previous function
        if portfolio is not None :
            portfolio = pd.DataFrame(portfolio)

        if payment_dates is not None:
            payment_dates = pd.DataFrame(payment_dates)
            coupon_payment_dates, notional_payment_dates = fct.get_paym(payment_dates["Coupon Payment Dates"],
                                                                       payment_dates["Notional Payment Dates"])
        checks = np.array([recovery_rate_error[0] is None,
                           reinvest_rate_error[0] is None,
                           portfolio is not None,
                           payment_dates is not None,
                           children_max_maturity[0] is None,
                           ])
        if checks.all() :
            recovery_rate = fct.take_number(recovery_rate)
            reinvest_rate = fct.take_number(reinvest_rate)
#            import pdb; pdb.set_trace()


            Portfolio_Crncy = portfolio["CRNCY"].astype('category')
            CrncyList = pd.concat([Portfolio_Crncy,
                                   pd.DataFrame([cncy])], ignore_index= True)[0]
            CrncyList = np.unique(CrncyList)

            df_fx_rates = df_fx_rates_func(True,CrncyList,folder)
            df_swap_rates = df_swap_rates_func(True,CrncyList,folder)

            # Maximum maturity in years
            MaxMaturity = int(max( np.ceil( fct.year_frac( asof_date, coupon_payment_dates[len(coupon_payment_dates)-1] ) ),
                                  np.ceil( fct.year_frac( asof_date, notional_payment_dates[len(notional_payment_dates)-1] ) ) ) )

            end_date = fct.add_years(asof_date, MaxMaturity)
            list_date = fct.dates_between(asof_date, end_date)
            
#            import pdb; pdb.set_trace()
            coupon_cash_flow_bbg, notional_cash_flow_bbg = parsing_cashflow(portfolio, list_date,
                                                                            True, folder)

            result_df = qrg_api.fct_buy_and_hold_analysis(recovery_rate, cncy, reinvest_rate, penalized_bonds,
#            result_df = buy_and_hold_analysis(recovery_rate, cncy, reinvest_rate, penalized_bonds,
                                              portfolio, payment_dates,
                                              df_fx_rates, df_swap_rates,
                                              coupon_cash_flow_bbg, notional_cash_flow_bbg,
                                              folder, download_from_bbg = True)
            super_gross_YTM = '{:1.2f}%'.format(result_df.loc['Fx Hedged', 'No Default']*100)
            gross_YTM = '{:1.2f}%'.format(result_df.loc['Fx Hedged and Reinvestment', 'No Default']*100)
            estimated_gross_YTM = '{:1.2f}%'.format(result_df.loc['Fx Hedged and Reinvestment', 'Default']*100)
        else :
            super_gross_YTM, gross_YTM, estimated_gross_YTM = 0,0,0

        return super_gross_YTM, gross_YTM, estimated_gross_YTM
    else:
        return 0,0,0


if __name__ == '__main__':
    app.run_server(debug=True)
