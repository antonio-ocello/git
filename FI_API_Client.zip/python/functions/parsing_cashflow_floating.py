# -*- coding: utf-8 -*-
"""
Created on Tue Oct  6 14:50:28 2020

@author: Gen2113948
"""


import pandas as pd
import numpy as np

import sys
sys.path.append("C:/QRG/")
from FI_API_Client.python.functions.parsing_cashflow import parsing_cashflow
from FI_API_Server.api.codes.functions.utils  import non_void_cash_flows, add_years, dates_between
from FI_API_Server.api.codes.functions.xirr_func import xirr

from datetime import date
#from datetime import datetime
from datetime import timedelta


# =============================================================================
# #TEST
# df_info = pd.read_csv("Z:/Users/Jean/B&H/Dag 2020-09-25/QRG_data.csv")
# 
# download_from_bbg =True
# one_day = timedelta(days=1)
# asof_date = pd.to_datetime(date.today() - one_day) 
# MaxMaturity = 6
# end_date = add_years(asof_date, MaxMaturity)
# list_date = dates_between(asof_date, end_date) 
# 
# Portfolio__ = pd.DataFrame({'ISIN':sorted(['SE0010830950','FI4000383930','NO0010851728','NO0010875826','XS1768718576'])})
# default_proba_folder = 'Z:/Users/Jean/B&H/Dag 2020-09-25/output python/fixed/'
# 
# 
# 
# FRNs = sorted(['SE0012728830','SE0011310606','NO0010832710','NO0010868912','NO0010846280','SE0013381662','SE0011282649','NO0010865876','SE0012622249','NO0010885312',
# 'SE0012256741','NO0010868433','SE0011721497','SE0011167204','SE0013409570','NO0010797491','NO0010831597','NO0010848401','SE0013409455','NO0010812092',
# 'SE0012377299','NO0010850050','NO0010852742','NO0010861313','NO0010861768','NO0010864531','DK0030452263','NO0010866163','NO0010869720','NO0010869761',
# 'NO0010874050','NO0010874530','NO0010885007','SE0012673952'])
# Portfolio_only_floating = Portfolio[Portfolio.CPN_TYP == 'FLOATING']
# list_bond_to_exclude = ['SE0012728830','SE0013381662','SE0011310606','SE0011282649','SE0012673952']
# =============================================================================


# =============================================================================
# REMARK: here we assume two things: that all the coupons are paid QUATERLY (freq_coupon_payment)
# and the last coupon and the last notional are paid together
# 
# if not the case: CHANGE
# =============================================================================

def parsing_cashflow_floating(Portfolio_only_floating, list_date, download_from_bbg = True, folder= ''):
    asof_date = list_date[0]  #TO CHECK
#    folder = 'Z:/Users/Jean/B&H/Dag 2020-09-25/output python/floating/'
    
    ## FIXED BRANCH
    #coupon_cash_flow, notional_cash_flow = parsing_cashflow(Portfolio__, list_date, download_from_bbg, default_proba_folder)
    #coupon_cash_flow.index = sorted(Portfolio__.ISIN)
    #notional_cash_flow.index = sorted(Portfolio__.ISIN)
    #coupon_cash_flow.to_csv(default_proba_folder + 'coupon_cash_flow_fixed.csv')
    #notional_cash_flow.to_csv(default_proba_folder + 'notional_cash_flow_fixed.csv')
    #total_cash_flows_fixed = coupon_cash_flow+ notional_cash_flow
    #
    #total_cash_flows_fixed.index = sorted(Portfolio__.ISIN)
    #total_cash_flows_fixed.to_csv("Z:/Users/Jean/B&H/Dag 2020-09-25/output python/total_cash_flows_fixed.csv")
    
    
    # parsing the normal cashflows and manipulating them looking at the YAS_BOND_YLD, a better indicator of the cashflows in the FLOATING
    #Portfolio___FRNs = pd.DataFrame({'ISIN':FRNs})
    Portfolio___FRNs = Portfolio_only_floating.ISIN
    if download_from_bbg:
        coupon_cash_flow, notional_cash_flow = parsing_cashflow(Portfolio_only_floating, list_date, download_from_bbg, folder)
    else:
        coupon_cash_flow = pd.read_csv("Z:/Users/Jean/B&H/Dag 2020-09-25/output python/floating/python__notional_cash_flow_from_bbg.csv",index_col=0)
        notional_cash_flow = pd.read_csv("Z:/Users/Jean/B&H/Dag 2020-09-25/output python/floating/python__coupon_cash_flow_from_bbg.csv",index_col=0)
#        total_floating = coupon_cash_flow.add(notional_cash_flow)
    
    coupon_cash_flow_modified = coupon_cash_flow.copy(deep=True)*0
    
    for i in Portfolio___FRNs.index:
        FRN = Portfolio___FRNs[i]
        print(i, FRN)
        
        YAS_Dag_FRN = Portfolio_only_floating[Portfolio_only_floating['ISIN'] == FRN]['YAS_BOND_YLD']
        
        
        yield_found = False
        seuil = 2 #where to start for this zero search that gives the good coupon to have in order to achieve the correct
        freq_coupon_payment = 4 # how frequently coupon are paid, here QUATERLY
        
        final_notional = 1000000
        
        tested_yield = max(float(YAS_Dag_FRN - seuil),0)
        
        while ( yield_found == False):

            test = coupon_cash_flow.iloc[i].replace(0.,np.nan).dropna()
            test.loc[:] = tested_yield/freq_coupon_payment*final_notional/100    
            
            test.iloc[-1] += final_notional
            test[asof_date] = -final_notional
            test.index = pd.to_datetime(test.index)
            
            xirr_ = xirr( dict( test ) )*100
            
            if (abs(xirr_ - YAS_Dag_FRN) < 0.01).all():
                yield_found = True
                
            tested_yield += 0.005
    
#        print(tested_yield)
#        print(YAS_Dag_FRN)
        coupon_cash_flow_modified.iloc[i].loc[test.index] = test
        
    #for i in range(len(FRNs)):
    #    print(xirr( dict( coupon_cash_flow_modified.iloc[i].replace(0,np.nan).dropna() ) )*100 - df_info[df_info['ISIN'] == FRNs[i]]['YAS_BOND_YLD'])

    
    notional_cash_flow = coupon_cash_flow_modified.copy(deep = True)
    notional_cash_flow[notional_cash_flow >= 1000000] = 1000000
    notional_cash_flow[notional_cash_flow < 1000000] = 0
    
    coupon_cash_flow = coupon_cash_flow_modified - notional_cash_flow
#    coupon_cash_flow.index = FRNs
#    notional_cash_flow.index = FRNs
#    coupon_cash_flow_modified.index = FRNs
#    coupon_cash_flow_modified.to_csv("Z:/Users/Jean/B&H/Dag 2020-09-25/output python/coupon_cash_flow_modified.csv")
    coupon_cash_flow.to_csv(folder + "/coupon_cash_flow_modified_floating.csv")
    notional_cash_flow.to_csv(folder + "/notional_cash_flow_modified_floating.csv")
    
    
    return coupon_cash_flow, notional_cash_flow


















