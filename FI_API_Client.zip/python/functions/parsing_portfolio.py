# -*- coding: utf-8 -*-
"""
Created on Tue Aug 11 12:00:48 2020

@author: d75188
"""

import pandas as pd
import numpy as np

import logging
logging.basicConfig()
logger = logging.getLogger('')

from datetime import datetime

#import sys
#sys.path.append('C:/QRG')
#from FI_API_Server.api.codes.functions.utils import rating_clean, rating_converter_MOODY_to_SP


def rating_clean(rating):
    '''
    rating = rating that is extracted from *blp.bdp*

    It clean the rating in order to make it belonging to ['AAA','AA', 'A','BBB','BB','B','CCC','CC','D']
    or the MOODY's ratings
    '''
    # cleaning update
    if type(rating)!= str:
        return rating
    elif len(rating) == 1: #for exemple A or B
        return rating

    # returning the same rating if it does not belong at all to the rating set, it is shown by the first
    #character of "rating"
    if rating[0] not in ['A','B','C','D']:
        return rating
    #if the first character is A, B, C or D we have a rating we need to take
    if len(rating) > 3 : #removing all the characters beyond the third
        rating = rating[:3]

    i=0
    while i < len(rating) and rating[i] in ['A','B','C','D','a']:
        i+=1
    rating = rating[:i]
    if rating == 'CC':
        rating = 'CCC'
    
    return rating

def rating_converter_MOODY_to_SP(rating, aggregated = True):
    '''
    table of convertion from the rating of Moody's to the one of S&P - Fitch
    '''
    if aggregated:
        rating = rating_clean( rating )
        converter = {'Aaa':'AAA', 'Aa': 'AA', 'A': 'A', 'Baa': 'BBB', 'Ba': 'BB','B': 'B', 'Caa': 'CCC', 'Ca': 'CC', 'C': 'D'}
    else:
        converter = {'Aaa':'AAA', 'Aa1': 'AA+', 'Aa2': 'AA', 'Aa3': 'AA-',
                     'A1': 'A+', 'A2': 'A', 'A3': 'A-', 'Baa1': 'BBB+', 'Baa2': 'BBB', 'Baa3': 'BBB-', 
                     'Ba1': 'BB+', 'Ba2': 'BB', 'Ba3': 'BB-', 'B1': 'B+', 'B2': 'B', 'B3': 'B-',
                     'Caa1': 'CCC+', 'Caa2': 'CCC', 'Caa3': 'CCC-', 'Ca': 'CC', 'C': 'D'}
    return converter[rating]


def parsing_portfolio(Portfolio,folder,download_from_bbg=True):
    # download_from_bbg = False
    if download_from_bbg :
        from xbbg import blp
        # Retrieve ISINs and download data with Bloomberg

        if 'Weight' in Portfolio.columns:
            Portfolio = Portfolio[['ISIN', 'Weight']]
        else:
            Portfolio = Portfolio[['ISIN']]
            Portfolio['Weight'] = 1/Portfolio.shape[0]

        # since blp.bdp sort in alphabetical order by ISIN the output
        # we do the same to our Portfolio
        Portfolio = Portfolio.sort_values(by = ['ISIN'])
        Portfolio.index = range(len(Portfolio.index))

        bbgISIN = '/isin/'+Portfolio.ISIN
        bbg_fields = ["CRNCY", "MATURITY", "BB_COMPOSITE", "INDUSTRY_SECTOR",
                      "PX_DIRTY_ASK", "BQ_FACE_AMT", "YLD_CNV_ASK", 'CPN_TYP',
                      'YAS_BOND_YLD', 'RTG_SP', 'RTG_MOODY', 'RTG_FITCH']
        
        bdp_result = blp.bdp(tickers = bbgISIN, flds = bbg_fields)
        bdp_result.index = range(len(Portfolio.index))
        bdp_result.columns = bdp_result.columns.str.upper()
        for col in ["CRNCY", "MATURITY", "BB_COMPOSITE", "INDUSTRY_SECTOR",
                    "PX_DIRTY_ASK", "BQ_FACE_AMT", "YLD_CNV_ASK", 'CPN_TYP',
                    'YAS_BOND_YLD', 'RTG_SP', 'RTG_MOODY', 'RTG_FITCH']:
            if col not in bdp_result.columns:
                bdp_result[col] = np.nan

        Portfolio = pd.concat([Portfolio,bdp_result], axis = 1, sort = False)

        Portfolio["PRICE_CONVENTION"] = 100.
        Portfolio["TIMESTAMP"] = datetime.now().strftime('%Y-%m-%d %X')
        Portfolio.MATURITY = pd.to_datetime(Portfolio.MATURITY)
        
        rating = Portfolio[['ISIN','RTG_SP', 'RTG_MOODY', 'RTG_FITCH']]
        Portfolio = Portfolio.drop(axis=1, columns= ['RTG_SP', 'RTG_MOODY', 'RTG_FITCH'] )
        
        # write to base file
        Portfolio.to_csv(folder +'new_portfolio.csv')
        rating.to_csv(folder + 'rating.csv')


    else:
        # No Bloomberg update, we only retrieve csv infos
        Portfolio = pd.read_csv( folder +'new_portfolio.csv', header = 0, index_col=0)
        rating = pd.read_csv(folder + 'rating.csv', header = 0, index_col=0)
        Portfolio.MATURITY = pd.to_datetime(Portfolio.MATURITY)
        Portfolio.index = range(Portfolio.shape[0])
        bbgISIN = '/isin/'+Portfolio.ISIN


    for i in range(len(Portfolio.BB_COMPOSITE)):
        Portfolio.BB_COMPOSITE[i] = rating_clean( Portfolio.BB_COMPOSITE[i])
#    Portfolio.BB_COMPOSITE = fc.rating_clean_vec(Portfolio.BB_COMPOSITE)

    # check if cash in Portfolio
    if ('FR0000287716' == Portfolio.ISIN).any() :
        weight_cash = Portfolio[Portfolio.ISIN == 'FR0000287716'].Weight.values[0]

        Portfolio = Portfolio[Portfolio.ISIN != 'FR0000287716']
        Portfolio.index = range(Portfolio.shape[0])
        
        rating = rating[rating.ISIN != 'FR0000287716']
        rating.index = range(rating.shape[0])
    else:
        weight_cash = 0



    # Search and change of lines where rating is WR or else from ['AAA','AA','A','BBB','BB','B','CCC']

    not_good_rating = np.array([rate not in ['AAA','AA','A','BBB','BB','B','CCC']
                                    for rate in Portfolio['BB_COMPOSITE']])
    rating_from_SandP = []
    rating_from_Moodys = []
    rating_from_Fitch = []
    rating_empty = []
    bdp_result_bad_index = []
    
    
    if not_good_rating.any() :
        rating = rating[ not_good_rating ]
        rating.to_csv(folder+'rating__notgoodratings.csv')

        for i in rating.index :
            try:
                if rating_converter_MOODY_to_SP(
                        rating_clean(
                                rating['RTG_MOODY'].loc[i]
                                )
                        ) in ['AAA','AA','A','BBB','BB','B','CCC']:
                            
                    Portfolio.loc[i,'BB_COMPOSITE'] = rating_converter_MOODY_to_SP( rating_clean( rating['RTG_MOODY'].loc[i] ) )
                    rating_from_Moodys.append( Portfolio.loc[i,'ISIN'] )
                else:
                    raise
            except:
                try:
                    if rating_clean( rating['RTG_SP'].loc[i] ) in ['AAA','AA','A','BBB','BB','B','CCC']:
                        Portfolio.loc[i,'BB_COMPOSITE'] = rating_clean( rating['RTG_SP'].loc[i] )
                        rating_from_SandP.append( Portfolio.loc[i,'ISIN'] )
                    elif rating_clean(rating['RTG_SP'].loc[i]) == 'CC':
                        Portfolio.loc[i,'BB_COMPOSITE'] = 'CCC'
                        rating_from_SandP.append( Portfolio.loc[i,'ISIN'] )
                    else:
                        raise
                    
                except:
                    try:
                        if rating_clean( rating['RTG_FITCH'].loc[i] ) in ['AAA','AA','A','BBB','BB','B','CCC']:
                            Portfolio.loc[i,'BB_COMPOSITE'] = rating_clean( rating['RTG_FITCH'].loc[i] )
                            rating_from_Fitch.append(Portfolio.loc[i,'ISIN'])
                        elif rating_clean(rating['RTG_FITCH'].loc[i]) == 'CC':
                            Portfolio.loc[i,'BB_COMPOSITE'] = 'CCC'
                            rating_from_Fitch.append(Portfolio.loc[i,'ISIN'])
                        else:
                            raise
                    except:
                        print(Portfolio.loc[i,'ISIN'])
                        rating_empty.append(Portfolio.loc[i,'ISIN'])
                        bdp_result_bad_index.append(i)
                        logger.error(' No rating as been found for this bond')

    # Check for rating errors
    bdp_result = Portfolio[Portfolio.index.isin(bdp_result_bad_index)]

    Portfolio.to_csv(folder +'new_portfolio-ratings_solved.csv')

    return Portfolio, rating_from_SandP, rating_from_Moodys, rating_from_Fitch, bdp_result, weight_cash


Portfolio = pd.DataFrame(columns = ['ISIN','Weight'], index = range(2))
Portfolio.ISIN = ['XS2025466413', 'ES0211845294']
Portfolio.Weight = [1,1]

folder = 'Z:/Users/Antonio/BnH/'
