# -*- coding: utf-8 -*-
"""
Created on Wed Sep  2 10:55:30 2020

@author: Laure Vidaud
"""

import pandas as pd
import numpy as np
from datetime import date
import collections
import cvxpy as cp 
from datetime import datetime
import math

import sys
sys.path.append('C:/QRG')

from FI_API_Server.api.codes.functions.func_optim import convert_to_datetime, yield_adjusted_default
from FI_API_Server.api.codes.functions.cumulated_def_from_ST_and_LT import cumulated_def_from_ST_and_LT

from FI_API_Client.python.functions.parsing_universe import parsing_universe 


constraints ={
"bool_B-" : True,
"bool_callable" : False,
"bool_Energy" : False,
"bool_Senior" : False,
"num_Start_Date" : 2025,
"num_End_Date" : 2025,
"num_Max_Sector" : 1.,
"num_Max_Country" : 1.,
"num_Max_Issuers_IG" : 0.05,
"num_Max_Issuers_HY" : 0.03,
"num_Max_HY" : 0.30,
"num_Max_Isin" : 0.025,
"num_Max_SumWeight" : 1,
"bool_Reinv" : False, 
"bool_Default" : True}

bbg_xla = "C:/Program Files (x86)/BLOOMBRG/OBLMBERG/API/Office Tools/BloombergUI.xla"
bbg_dll = 'C:/Program Files (x86)/BLOOMBRG/OBLMBERG/API/Office Tools/bofaddin.dll'


folder = "Z:/Users/Laure/test bbg 18.xlsx"

df = parsing_universe(constraints, bbg_xla, bbg_dll,folder, currency='EUR')