# -*- coding: utf-8 -*-
"""
Created on Tue Sep 29 19:28:11 2020

@author: d75188
"""
import base64
import datetime
import io

import dash
import dash_core_components as dcc
import dash_html_components as html
from dash.dependencies import Input, Output, State
import dash_table
import dash_daq as daq

import pandas as pd
import numpy as np

colors = {
     'background_boxes': '#007348',
     'title' : '#8BC8AA',
     'subtitle' : '#39A87B',
     'text': '#007348',
     'error' : '#D8000C',
     'background_error' : '#FFD2D2',
     'S&P' : '#BDECFF',
     'Moodys' : '#BDBEFF',
     'Fitch' : '#F4BDFF',
     'no_rating' : '#FB7D7D',
     'neg_yields' : '#FBFB7D',
     'price>200' : "#FBB27D"
 }


def add_years(date_, nbr_years):
    '''Add a year to a date'''
    #tmp = datetime.strptime(date_, '%Y-%m-%d')
    return date_.replace(date_.year + nbr_years)


def dates_between(start_date, end_date):
    '''List of days between two dates'''
    return pd.date_range(start_date,end_date).tolist()


def year_frac(first_date, second_date):
    '''Year frac Act / 360'''
    return (second_date - first_date).days / 360.0


def percentage_to_float(x):
    return float(x.strip('%'))/100


def get_paym(coupon, notional):
    # Retrieve PM's payment dates
    bad_day_format = False
    try:
        coupon_payment_dates = pd.to_datetime(coupon, format='%Y-%m-%d')
    except:
        bad_day_format = True
        
    try:
        coupon_payment_dates = pd.to_datetime(coupon, format='%d/%m/%Y')
        bad_day_format = False
    except:
        bad_day_format = True
    
    if bad_day_format:
        coupon_payment_dates = pd.to_datetime(coupon)
    
    index_na_cpn_date = coupon_payment_dates.isna()
    coupon_payment_dates = coupon_payment_dates[~index_na_cpn_date]

    bad_day_format = False
    try:
        notional_payment_dates = pd.to_datetime(notional, format='%Y-%m-%d')
    except:
        bad_day_format = True
        
    try:
        notional_payment_dates = pd.to_datetime(notional, format='%d/%m/%Y')
        bad_day_format = False
    except:
        bad_day_format = True
    
    if bad_day_format:
        notional_payment_dates = pd.to_datetime(notional)

    index_na_not_date = notional_payment_dates.isna()
    notional_payment_dates = notional_payment_dates[~index_na_not_date]
    
    return coupon_payment_dates, notional_payment_dates

def error(string):
    string = string.replace(' ', '')
    string = string.replace(',', '.')
    try :
        if '%' == string[-1]:
            number = float(string[:-1])
            number /= 100
        else:
            number = float(string)
        if number < 0 or number > 1 :
            raise
    except :
        return dcc.Markdown(
                children = '''The input needs to be a number between 0 and 1.''',
                style = {'textAlign': 'center',
                         'color': colors['error'],
                         'backgroundColor' : colors['background_error']
                         })
    else :
        return

def take_number(string):
    string = string.replace(' ', '')
    string = string.replace(',', '.')
    if '%' == string[-1]:
        return float(string[:-1])/100.
    return float(string)

def error_date(string):
    try:
        pd.to_datetime([string])
    except:
        return dcc.Markdown(
                children = '''The selected input has not the good time format.''',
                style = {'textAlign': 'center',
                         'color': colors['error'],
                         'backgroundColor' : colors['background_error']
                         })
    else:
        return
# =============================================================================
# PARSING FUNCTIONS
# =============================================================================


def print_to_screen(df, filename, date):
    return html.Div([
        html.H5(filename),
        html.H6(datetime.datetime.fromtimestamp(date)),

        dash_table.DataTable(
            data=df.round(7).to_dict('records'),
            columns=[{'name': i, 'id': i} for i in df.columns],
            style_cell={
                'textAlign': 'center'
            },
#            style_cell_conditional=[
#                    {
#                            'if': {'column_id': 'ISIN'},
#                            'textAlign': 'center'
#                            }],
            style_data_conditional=[
                {
                    'if': {'row_index': 'odd'},
                    'textAlign': 'center',
                    'backgroundColor': 'rgb(248, 248, 248)'
                }
            ],
            style_header={
                'backgroundColor': colors['background_boxes'],
                'textAlign': 'center',
                'color': 'white',
                'fontWeight': 'bold'
            }
        ),

        html.Hr(),  # horizontal line

        # For debugging, display the raw contents provided by the web browser
#        html.Div('Raw Content'),
#        html.Pre(contents[0:200] + '...', style={
#            'whiteSpace': 'pre-wrap',
#            'wordBreak': 'break-all'
#        })
    ])

def parse_contents(contents, filename, flag_port_paym):
    content_type, content_string = contents.split(',')

    decoded = base64.b64decode(content_string)
    try:
        if 'csv' in filename:
            # Assume that the user uploaded a CSV file
            if flag_port_paym == 'portfolio':
                df = pd.read_csv(
                        io.StringIO(decoded.decode('utf-8')),sep=',')
                if 'ISIN' not in df.columns:
                    df = pd.read_csv(
                            io.StringIO(decoded.decode('utf-8')), sep=',',
                            header = None)
            elif flag_port_paym == 'payment_dates':
                df = pd.read_csv(
                        io.StringIO(decoded.decode('utf-8')),sep=',')
                try :
                    pd.to_datetime( df.columns )
                    # if error, the first lines is a timestamp that we need to consider the first line
                except :
                    pass
                else :
                    df = pd.read_csv(
                            io.StringIO(decoded.decode('utf-8')), sep=',',
                            header = None)
            elif flag_port_paym == 'list_tickers':
                df = pd.read_csv(io.BytesIO(decoded), header = None)
                df = df.rename(columns ={0:'tickers'})

        elif 'xls' in filename:
            # Assume that the user uploaded an excel file
            
            if flag_port_paym == 'portfolio':
                df = pd.read_excel(io.BytesIO(decoded))
                if 'ISIN' not in df.columns:
                    df = pd.read_excel(
                            io.BytesIO(decoded),
                            header = None)
            elif flag_port_paym == 'payment_dates':
                df = pd.read_excel(io.BytesIO(decoded))
                try :
                    pd.to_datetime( df.columns )
                except :
                    pass
                else :
                    # if before not error, than the first lines is a timestamp
                    df = pd.read_excel(
                            io.BytesIO(decoded),
                            header = None)
            elif flag_port_paym == 'list_tickers':
                df = pd.read_excel(io.BytesIO(decoded), header = None)
                df = df.rename(columns ={0:'tickers'})
                
    except:
        df = pd.DataFrame(['Error in parsing the file'])
#    except Exception as e:
#        print(e)
#        return html.Div([
#            'There was an error processing this file.'
#        ])

    return df