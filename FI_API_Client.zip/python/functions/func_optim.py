# -*- coding: utf-8 -*-
"""
Created on Fri Oct 16 17:40:17 2020

@author: d75188
"""

import numpy as np
import pandas as pd

def rating_clean(rating):
    '''
    rating = rating that is extracted from *blp.bdp*

    It clean the rating in order to make it belonging to ['AAA','AA', 'A','BBB','BB','B','CCC','CC','D']
    or the MOODY's ratings
    '''
    # cleaning update
    if type(rating)!= str:
        return rating
    elif len(rating) == 1: #for exemple A or B
        return rating

    # returning the same rating if it does not belong at all to the rating set, it is shown by the first
    #character of "rating"
    if rating[0] not in ['A','B','C','D']:
        return rating
    #if the first character is A, B, C or D we have a rating we need to take
    if len(rating) > 3 : #removing all the characters beyond the third
        rating = rating[:3]

    i=0
    while i < len(rating) and rating[i] in ['A','B','C','D','a']:
        i+=1
    rating = rating[:i]
    if rating == 'CC':
        rating = 'CCC'
    
    return rating

rating_clean_vec = np.vectorize(rating_clean)


def rating_converter_MOODY_to_SP(rating, aggregated = True):
    '''
    table of convertion from the rating of Moody's to the one of S&P - Fitch
    '''
    if aggregated:
        rating = rating_clean( rating )
        converter = {'Aaa':'AAA', 'Aa': 'AA', 'A': 'A', 'Baa': 'BBB', 'Ba': 'BB','B': 'B', 'Caa': 'CCC', 'Ca': 'CC', 'C': 'D'}
    else:
        converter = {'Aaa':'AAA', 'Aa1': 'AA+', 'Aa2': 'AA', 'Aa3': 'AA-',
                     'A1': 'A+', 'A2': 'A', 'A3': 'A-', 'Baa1': 'BBB+', 'Baa2': 'BBB', 'Baa3': 'BBB-', 
                     'Ba1': 'BB+', 'Ba2': 'BB', 'Ba3': 'BB-', 'B1': 'B+', 'B2': 'B', 'B3': 'B-',
                     'Caa1': 'CCC+', 'Caa2': 'CCC', 'Caa3': 'CCC-', 'Ca': 'CC', 'C': 'D'}
    return converter[rating]