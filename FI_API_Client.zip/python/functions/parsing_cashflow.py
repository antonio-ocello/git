import pandas as pd
import numpy as np

#from datetime import datetime

def parsing_cashflow(Portfolio, list_date, download_from_bbg = True, folder= ''):

    if download_from_bbg:
        from xbbg import blp
        # Retrieve all cash-flows
        print("Retrieve each bond's cashflow table")

        coupon_cash_flow = pd.DataFrame( np.zeros( (len(Portfolio.index), len(list_date)) ), columns = list_date )
        notional_cash_flow = pd.DataFrame( np.zeros( (len(Portfolio.index), len(list_date)) ), columns = list_date )

        for i in range(Portfolio.shape[0]):
            bond_isin = Portfolio.ISIN[i].upper() # actually no need in python to do upper()

            print( str(i+1)+"/"+str(len(Portfolio.index))+" : "+ bond_isin )

            if blp.bdp(tickers = "/isin/"+ str(bond_isin),flds = "ID_ISIN")["id_isin"][0] == "" :
                i = blp.bdp(tickers = "/cusip/" + str(bond_isin),flds = "ID_ISIN")["id_isin"]

            des_cash_flow = blp.bds("/isin/"+str(bond_isin),"DES_CASH_FLOW")

            for index_cash_flow in range(len(des_cash_flow.index)):
                cf_payment_date = des_cash_flow["payment_date"].iloc[index_cash_flow]
                cf_coupon = des_cash_flow["coupon_amount"].iloc[index_cash_flow]
                cf_notional = des_cash_flow["principal_amount"].iloc[index_cash_flow]

                coupon_cash_flow.loc[i, str(cf_payment_date)] = cf_coupon
                notional_cash_flow.loc[i, str(cf_payment_date)] = cf_notional

        # Format as date
        coupon_cash_flow.columns = pd.to_datetime(coupon_cash_flow.columns)
        notional_cash_flow.columns = pd.to_datetime(notional_cash_flow.columns)

        coupon_cash_flow.to_csv(folder + 'coupon_cash_flow_from_bbg.csv')
        notional_cash_flow.to_csv(folder + 'notional_cash_flow_from_bbg.csv')
    else:
        coupon_cash_flow = pd.read_csv(folder + 'coupon_cash_flow_from_bbg.csv', index_col=0)
        coupon_cash_flow.columns = pd.to_datetime(coupon_cash_flow.columns)
        notional_cash_flow = pd.read_csv(folder + 'notional_cash_flow_from_bbg.csv', index_col=0)
        notional_cash_flow.columns = pd.to_datetime(notional_cash_flow.columns)

    coupon_cash_flow.index = range(Portfolio.shape[0])
    notional_cash_flow.index = range(Portfolio.shape[0])

    return coupon_cash_flow, notional_cash_flow
