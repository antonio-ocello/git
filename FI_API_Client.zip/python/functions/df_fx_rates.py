# -*- coding: utf-8 -*-
"""
Created on Tue Jul 28 16:55:27 2020

@author: d75188
"""

import pandas as pd
import numpy as np

def ticker_name_fx(ccy1, ccy2):
        # If both currencies are the same
        if(ccy1 == ccy2):
            return(1.0)
        else:
            return( ccy1.upper() + ccy2.upper() + " Curncy" )

# =============================================================================
# Loading of forex rates
# =============================================================================

def df_fx_rates_func(download_from_bbg,CrncyList,folder=''):
    if download_from_bbg:
        from xbbg import blp
        df_fx_rates = pd.DataFrame( np.ones((len(CrncyList),len(CrncyList))) )
        df_fx_rates.columns = CrncyList
        df_fx_rates.index = CrncyList

        # Load all fx rates
        print("Retrieve forex rates from Bloomberg")
        for i in range(len(CrncyList)):
            for j in range(len(CrncyList)):
                ij_ticker_name_fx = ticker_name_fx(CrncyList[i], CrncyList[j])
                print( CrncyList[i] + " - " + CrncyList[j])
                if ij_ticker_name_fx == 1.0:
                    df_fx_rates.loc[CrncyList[i],CrncyList[j]] = 1.0
                else:
                    df_fx_rates.loc[CrncyList[i],CrncyList[j]] = blp.bdp( tickers = ij_ticker_name_fx, flds = "PX_LAST" ).iloc[0,0]
        df_fx_rates.to_csv( folder + 'df_fx_rates.csv')
    else:
        df_fx_rates = pd.read_csv( folder + 'df_fx_rates.csv', header = 0, index_col=0)
    return df_fx_rates
