# -*- coding: utf-8 -*-
"""
Created on Tue Jul 28 17:20:42 2020

@author: d75188
"""

import pandas as pd

def ticker_name(ccy,mat):
    if ccy=="USD" :
        if mat==0 :
            return "US0001M Index"
        else:
            return "USSWAP" + str(mat) + " Curncy"

    elif ccy=="EUR" :
        if mat==0 :
            return "EUR001M Index"
        elif mat==1 :
            return "DMSW1 Curncy"
        else:
            return "EUSA" + str(mat) + " Curncy"

    elif ccy=="GBP" :
        if mat==0 :
            return "BP0001M Index"
        elif mat==1 :
            return "BPSW1 BGN Curncy"
        else:
            return "BPSW" + str(mat) + " Curncy"

    elif ccy=="NOK" :
        if mat==0 :
            return "NIBOR1M Index"
        else:
            return "NKSW" + str(mat) + " Curncy"
    elif ccy=="SEK":
        if mat==0 :
            return "STIB1M Index"
        else:
            return "SKSW" + str(mat) + " Curncy"

#===============================================================================
# 					 Loading of swap rates
#===============================================================================
def df_swap_rates_func(download_from_bbg,CrncyList,folder=''):
    if download_from_bbg :
        from xbbg import blp
        df_swap_rates = pd.DataFrame()
        rate_horizon = 7

        # Function to get the right BBG ticker for each currency (Need Bloomberg if rates data are not present)
        print("Retrieve swap rates from Bloomberg")

        colNames = ["sw" + str(i) + "y" for i in range(rate_horizon+1)]

        for j in range(len(CrncyList)):
            for k in range(rate_horizon+1):
                print( ticker_name(CrncyList[j],k) )
                currency_swap_rates = blp.bdp( tickers = ticker_name(CrncyList[j],k) ,flds = "PX_LAST" ).iloc[0,0]

                df_swap_rates.loc[CrncyList[j],colNames[k]] = currency_swap_rates

        df_swap_rates.to_csv( folder + 'df_swap_rates.csv')
    else:
        df_swap_rates = pd.read_csv( folder + 'df_swap_rates.csv', header = 0, index_col=0)
    return df_swap_rates
