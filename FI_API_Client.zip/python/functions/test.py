# -*- coding: utf-8 -*-
"""
Created on Wed Oct 14 15:00:16 2020

@author: d75188
"""

import win32com.client

#Excel file of Universe tickers opening
bbg_xla = "C:/Program Files (x86)/BLOOMBRG/OBLMBERG/API/Office Tools/BloombergUI.xla"
bbg_dll = 'C:/Program Files (x86)/BLOOMBRG/OBLMBERG/API/Office Tools/bofaddin.dll'
folder = "Z:/Users/Laure/test bbg 17.xlsx"

from time import sleep
import pandas as pd

#import sys
#sys.path.append('C:/QRG')
#from FI_API_Server.api.codes.functions.utils import rating_converter_MOODY_to_SP

#from pathlib import Path

import logging
logging.basicConfig()
logger = logging.getLogger('')


currency='EUR'

constraints ={
"bool_B-" : True,
#"bool_callable" : False,
"bool_Energy" : False,
"bool_Senior" : False,
"num_Start_Date" : 2025,
"num_End_Date" : 2025,
"num_Max_Sector" : 1.,
"num_Max_Country" : 1.,
"num_Max_Issuers_IG" : 0.05,
"num_Max_Issuers_HY" : 0.03,
"num_Max_HY" : 0.30,
"num_Max_Isin" : 0.025,
"num_Max_SumWeight" : 1,
"bool_Reinv" : False,
"bool_Default" : True
}


def rating_converter_MOODY_to_SP(rating):
    '''
    table of convertion from the rating of Moody's to the one of S&P - Fitch
    '''
    converter = {'Aaa':'AAA', 'Aa1': 'AA+', 'Aa2': 'AA', 'Aa3': 'AA-',
                     'A1': 'A+', 'A2': 'A', 'A3': 'A-', 'Baa1': 'BBB+', 'Baa2': 'BBB', 'Baa3': 'BBB-',
                     'Ba1': 'BB+', 'Ba2': 'BB', 'Ba3': 'BB-', 'B1': 'B+', 'B2': 'B', 'B3': 'B-',
                     'Caa1': 'CCC+', 'Caa2': 'CCC', 'Caa3': 'CCC-', 'Ca': 'CC', 'C': 'D'}
    return converter[rating]

# TO CHANGE
def rating_clean(rating):
    '''
    rating = rating that is extracted from *blp.bdp*

    It clean the rating in order to make it belonging to ['AAA','AA', 'A','BBB','BB','B','CCC','CC','D']
    or the MOODY's ratings
    '''
    # cleaning update
    if type(rating)!= str:
        return rating
    elif len(rating) == 1: #for exemple A or B
        return rating

    # returning the same rating if it does not belong at all to the rating set, it is shown by the first
    #character of "rating"
    if rating[0] not in ['A','B','C','D']:
        return rating
    #if the first character is A, B, C or D we have a rating we need to take
    if len(rating) > 3 : #removing all the characters beyond the third
        rating = rating[:3]

    i=0
    while i < len(rating) and rating[i] in ['A','B','C','D','a']:
        i+=1
    rating = rating[:i]
    if rating == 'CC':
        rating = 'CCC'
    
    return rating


def parsing_universe(constraints,bbg_xla,bbg_dll,folder, currency='EUR'):
    excel = win32com.client.DispatchEx("Excel.Application")
    
    excel.RegisterXLL(bbg_dll)
    excel.Workbooks.Open(bbg_xla)
    
    wb = excel.Workbooks()
    excel.Visible = True# à retirer pour la prod
    
    
    ws = wb.Worksheets('Sheet1')
    
    #BQL request
    string = '''=BQL("filter(bondsuniv('active'),IN(TICKER,"&BQL.List(A1:A'''
    string += str(list_ticker.shape[0])
    string += ''')&")  AND Year(Maturity)==\''''
    string += str(constraints["num_Start_Date"])
    string += '''\' AND YIELD(side=ask, yield_type='YTW')!=NaN AND classification_name(BICS,2)!= NaN AND CRNCY==\''''
    string += currency
    string += '''\')","name, Maturity, BB_COMPOSITE().value as #Rating, '''
    string += '''RTG_SP().value, RTG_MOODY().value, RTG_FITCH().value, '''
    string += '''YIELD(side=ask, yield_type='YTW').value as #AskYTW, classification_name(BICS,3) as 
    #Classification, payment_rank, cntry_of_risk, CRNCY, Ticker, ID_ISIN", "pricing_source=bgn")'''
    
    print(string)
    
    print(ws.Cells(10, 10).Value)
    ws.Cells(10, 10).Value = string
    
    while(ws.Cells(1,2).Value == '#N/A Requesting Data...'):
          print('loading data please wait ... ')
          sleep(5)
    
    dic_col_names =  {"ID" : "B", "name" : "C", "Maturity" : "D", "#Rating" : "E", "RTG_SP().value" : "F",
                     "RTG_MOODY().value" : "G", "RTG_FITCH().value" : "H", "#AskYTW" : "I", "#Classification" : "J", "payment_rank" : "K",
                     "cntry_of_risk" : "L", "CRNCY" : "M", "Ticker" : "N", 'ID_ISIN' : 'O'}
    
    dic_data = {}
    for key in dic_col_names.keys():
        print(key)
        dic_data[key] = [str(el[0]) for el in list(ws.Range(dic_col_names[key] + ":" + dic_col_names[key]).Value) if str(el) != "(None,)"][1:]
    
    for key in dic_data:
        print(dic_data[key])
    
    df = pd.DataFrame(dic_data)
    df
    wb.Close(SaveChanges=0)
    
    #Excel file import and suppression of first column
    list_rating = ['AAA', 'AA+', 'AA', 'AA-', 'A+', 'A', 'A-', 'BBB+', 'BBB', 'BBB-',
                   'BB+', 'BB', 'BB-', 'B+', 'B', 'B-', 'CCC+', 'CCC', 'CCC-', 'CC',
                   'C', 'D']
    not_good_rating = ~df['#Rating'].isin(list_rating)
    
    if not_good_rating.any() :
        rating = df['#Rating'][ not_good_rating ]
    
        for i in rating.index :
            try:
                if rating_converter_MOODY_to_SP(
                        rating['RTG_MOODY().value'].loc[i],
                        aggregated = False
                        ) in list_rating :
    
                    df.loc[i,'#Rating'] = rating_converter_MOODY_to_SP( rating['RTG_MOODY().value'].loc[i], aggregated = False )
                else:
                    raise
            except:
                try:
                    if rating['RTG_SP().value'].loc[i] in list_rating:
                        df.loc[i,'#Rating'] = rating['RTG_SP().value'].loc[i]
                    else:
                        raise
    
                except:
                    try:
                        if rating['RTG_FITCH().value'].loc[i] in list_rating:
                            df.loc[i,'#Rating'] = rating['RTG_FITCH().value'].loc[i]
                        elif rating['RTG_FITCH().value'].loc[i] == 'CC':
                            df.loc[i,'#Rating'] = 'CCC'
                        else:
                            raise
                    except:
                        print(df.loc[i,'ID_ISIN'])
                        logger.error(' No rating as been found for this bond')
    df.columns =  ["ID", "name", "Maturity", "Rating", "RTG_SP", "RTG_MOODY", "RTG_FITCH", "AskYTW",
                   "Classification", "Payment_rank", "Cntry_of_risk", "CRNCY", "Ticker", 'ISIN']
    
    return df




df = parsing_universe(constraints,bbg_xla,bbg_dll,folder, currency='EUR')
print(df)