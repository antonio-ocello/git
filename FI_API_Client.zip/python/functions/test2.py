# -*- coding: utf-8 -*-
"""
Created on Wed Oct 14 15:00:16 2020

@author: d75188
"""

import win32com.client

#Excel file of Universe tickers opening
bbg_xla = "C:/Program Files (x86)/BLOOMBRG/OBLMBERG/API/Office Tools/BloombergUI.xla"
bbg_dll = 'C:/Program Files (x86)/BLOOMBRG/OBLMBERG/API/Office Tools/bofaddin.dll'
folder = "Z:/Users/Laure/test bbg 17.xlsx"

from time import sleep
import pandas as pd

#import sys
#sys.path.append('C:/QRG')
#from FI_API_Server.api.codes.functions.utils import rating_converter_MOODY_to_SP

#from pathlib import Path

import logging
logging.basicConfig()
logger = logging.getLogger('')


currency='EUR'
constraints ={
"bool_B-" : True,
#"bool_callable" : False,
"bool_Energy" : False,
"bool_Senior" : False,
"num_Start_Date" : 2025,
"num_End_Date" : 2025,
"num_Max_Sector" : 1.,
"num_Max_Country" : 1.,
"num_Max_Issuers_IG" : 0.05,
"num_Max_Issuers_HY" : 0.03,
"num_Max_HY" : 0.30,
"num_Max_Isin" : 0.025,
"num_Max_SumWeight" : 1,
"bool_Reinv" : False,
"bool_Default" : True
}



excel = win32com.client.DispatchEx("Excel.Application")

excel.RegisterXLL(bbg_dll)
excel.Workbooks.Open(bbg_xla)


#wb = excel.Workbooks.Open(folder,None,False)

wb = excel.Workbooks.Add()
ws = wb.Worksheets('Sheet1')

#list_ticker = pd.read_excel(folder, header = None)
list_ticker = pd.Series(['ABIBB', 'ABBV', 'ABESM'])

excel.Visible = True # à retirer pour la prod

#BQL request
string = '''=BQL("filter(bondsuniv('active'),IN(TICKER,"&BQL.List(A1:A'''
string += str(list_ticker.shape[0])
string += ''')&")  AND Year(Maturity)==\''''
string += str(constraints["num_Start_Date"])
string += '''\' AND YIELD(side=ask, yield_type='YTW')!=NaN AND classification_name(BICS,2)!= NaN AND CRNCY==\''''
string += currency
string += '''\')","name, Maturity, BB_COMPOSITE().value as #Rating, '''
string += '''RTG_SP().value, RTG_MOODY().value, RTG_FITCH().value, '''
string += '''YIELD(side=ask, yield_type='YTW').value as #AskYTW, classification_name(BICS,3) as 
#Classification, payment_rank, cntry_of_risk, CRNCY, Ticker, ID_ISIN", "pricing_source=bgn")'''
ws.Cells(1,2).Value = string