from numpy import dtype
import json
from pandas import to_datetime, read_json

import logging
formatter = logging.Formatter('%(asctime)s %(levelname)s: %(message)s', datefmt='%d/%m/%Y %H:%M:%S')


def setup_logger(name, log_file, level=logging.DEBUG, mode='w'):
    """Function setup as many loggers as you want"""

    handler = logging.FileHandler(log_file, mode=mode)
    handler.setFormatter(formatter)

    logger = logging.getLogger(name)
    logger.setLevel(level)
    logger.addHandler(handler)

    return logger


class APIException(Exception):
    def __init__(self, *args, **kwargs):
        response = kwargs.pop('response', None)
        super(APIException, self).__init__(*args)
        self.response = response


def parts_to_curl(method, endpoint, headers, data=None):
    ignored_headers = (
        'Accept', 'Accept-Encoding', 'Connection', 'Content-Type', 'Content-Length', 'User-Agent')
    headers = ["'{0}:{1}'".format(k, v) for k, v in headers.items() if
               k not in ignored_headers]
    headers = " -H ".join(sorted(headers))

    curl_parameters = ['curl']
    for prefix, values in (('-X', method.upper()),
                           ('-H', headers),
                           ('-d', "'%s'" % data if data else None),
                           ):
        if values:
            curl_parameters.append('%s %s' % (prefix, values))
    curl_parameters.append("'%s'" % endpoint)
    command = " ".join(curl_parameters)
    return command


def to_curl(request):
    if not request:
        return 'No request'
    return parts_to_curl(request.method,
                         request.url,
                         request.headers,
                         request.body if getattr(request, 'body') else None)


def unserialize_dataframe(response_json):
    df_json, dtypes_json = response_json['dataframe_json'], response_json['types_json']
    dtypes = json.loads(dtypes_json)
    true_dtypes = {}
    date_columns = []
    for k, v in dtypes.items():
        v_dtype = dtype(v[0][1])
        if v_dtype == dtype('datetime64[ns]'):
            true_dtypes[k] = dtype('int64')
            date_columns.append(k)
        else:
            true_dtypes[k] = v_dtype
    df_ = read_json(df_json, orient='columns', dtype=true_dtypes)
    for df_col in date_columns:
        df_[df_col] = to_datetime(df_[df_col], unit='ns')
    return df_


def serialize_dataframe(df_):
    dataframe_json = df_.to_json(date_format='epoch', date_unit='ns')
    types_json = json.dumps({k: v.descr for k, v in df_.dtypes.to_dict().items()})
    data_dict = {
        'dataframe_json': dataframe_json,
        'types_json': types_json
    }
    return data_dict