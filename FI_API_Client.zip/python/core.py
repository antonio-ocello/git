"""
QRGFixedIncomeApi is the class to use to communicate with QRG Team
"""
import json
import logging
from os.path import exists, abspath, dirname
from os import makedirs, getenv, system
import requests
from datetime import datetime
import pandas as pd

from .utils import to_curl, APIException, setup_logger, unserialize_dataframe, serialize_dataframe

_VALID_METHODS = ('get', 'post')
VERSION = '1.0.0'


class QRGFixedIncomeApi(object):
    ###############################################################################
    # Functions for make to API work in a robust manner (connecting to different hosts)
    ###############################################################################

    def __init__(self):
        # load api key
        api_key = getenv('QRGFixedIncomeApiKey')
        if api_key is None:
            print('QRGFixedIncomeApiKey is not set. Enter your QRGFixedIncomeApiKey:')
            api_key = input()
            system("SETX {0} {1}".format("QRGFixedIncomeApiKey", api_key))
        self.api_key = api_key

        # list of post where API should be working
        self.hostnames = [
            {
                "name": "localhost",
                "address": "127.0.0.1",
                "port": 8001
            },
            {
                "name": "localhost",
                "address": "127.0.0.1",
                "port": 5000
            },
            {
                "name": "gen2113948",
                "address": "PARW0A214315",
                "port": 5000
            },
            # {
            #     "name": "gen2113948",
            #     "address": "PARW0A214315",
            #     "port": 5000
            # },
        ]

        # Hostname used for connexion
        self.chosen_hostname = 0
        self.base_url = None

        # variables for remote connection
        self.session = requests.Session()
        self.session.trust_env = False

        # Logging
        result_path_logs = abspath(dirname(__file__)) + '/../logs/'
        if not exists(result_path_logs):
            makedirs(result_path_logs)
        today_date = str(datetime.today().date()).replace(":", "-")
        log_file = result_path_logs+'Log QRGFixedIncomeApi - {}.log'.format(today_date)
        self.logger = setup_logger('pyQRG.core', log_file, level=logging.DEBUG, mode='w')

    @property
    def headers(self):
        """ Define headers for remote connection

        Returns
        -------
        dict
            authorization dict to connect to the API

        """
        return {
            "Authorization": "Bearer {}".format(self.api_key),
        }

    def build_base_url(self):
        """ Build URL from hostname dict and chosen hostname
        """
        hostname = self.hostnames[self.chosen_hostname]
        self.base_url = hostname['address'] + ':' + str(hostname['port'])

    def get_base_url(self):
        """ Get current url or build it if it does not exists

        Returns
        -------
        type
            Description of returned object.

        """
        if self.base_url is None:
            self.build_base_url()
        return self.base_url

    def request(self, endpoint, data=None, params=None, method='get', stream=False, timeout=None):
        """ Send a request to remote

        Parameters
        ----------
        endpoint : type
            method to call in GTS
        data : type
            in method POST we send data to remote
        params : type
            more params
        method : type
            GET or POST

        """
        # check if method make sens (GET or POST)
        assert method in _VALID_METHODS, \
            'Method {used} not accepted. Please choose one of {valid_methods}'.format(
                used=method, valid_methods=", ".join(_VALID_METHODS)
            )

        connexion = False
        while not connexion:
            # try to connect to a remote while there are untried remotes
            try:
                base_url = self.get_base_url()
                self.logger.debug("Request {method} to {base_url} {endpoint}".format(method=method,
                                                                                     base_url=base_url,
                                                                                     endpoint=endpoint))
                url = 'http://' + base_url + endpoint
                # get or post depending on method
                if method == "get":
                    response = self.session.get(
                        url=url,
                        headers=self.headers,
                        json=data,
                        params=params,
                        stream=stream,
                        timeout=timeout,
                    )
                elif method == "post":
                    response = self.session.post(
                        url=url,
                        headers=self.headers,
                        json=data,
                        params=params,
                        stream=stream,
                        timeout=timeout,
                    )
                else:
                    raise ValueError('Wrong Method')
                connexion = True
            except requests.exceptions.RequestException as e:
                self.logger.debug("Not accessing {base_url}".format(base_url=base_url))
                # is there still hostnames to try ?
                if self.chosen_hostname < len(self.hostnames) - 1:
                    self.chosen_hostname += 1
                    self.build_base_url()
                    self.logger.debug("Trying new hostname")
                else:
                    # all hostnames have been tried
                    raise ValueError('API NOT WORKING')

        self.logger.info("API query to %s" % to_curl(response.request))
        # 600 errors are for the database errors
        if response.status_code == 200 or str(response.status_code)[0] == '6':
            return response
        else:
            self.logger.error("Error calling the API, we tried: %s" % to_curl(response.request))
            raise APIException(
                'Got an error {status}: body was \'{error_message}\''.format(
                    status=response.status_code,
                    error_message=response.text
                ), response=response)

    def get_status(self):
        response = self.request('/status')
        return response.json()

    ##### Custom DEFINED FUNCTIONS

    def test_post_function(self, arg_1, arg_2):
        """
        Anything you want

        """
        # json dict will be send via POST requests
        json_dict = {
            'arg_1': arg_1,
            'arg_2': arg_2,
        }

        response = self.request(
            endpoint="/test_post_function",
            method='post',
            data=json_dict,
        )
        response_json = response.json()
        if response.status_code == 200:
            # df_response = unserialize_dataframe(response_json)
            df_response = response_json
            return df_response
        else:
            raise ValueError(response_json)

    def fct_buy_and_hold_analysis(self, RecoveryPrice, cncy, spread_cash, penalized_bonds,
                                  Portfolio, payment_dates,
                                  df_fx_rates, df_swap_rates,
                                  coupon_cash_flow_bbg, notional_cash_flow_bbg,
                                  folder,
                                  download_from_bbg = True):
        """
        function that computes the yields of the Buy&Hold portfolio
        """

        coupon_cash_flow_bbg.columns = coupon_cash_flow_bbg.columns.astype(str)
        notional_cash_flow_bbg.columns = notional_cash_flow_bbg.columns.astype(str)
        # json dict will be send via POST requests
        json_dict = {
            'RecoveryPrice': RecoveryPrice,
            'cncy': cncy,
            'spread_cash': spread_cash,
            'penalized_bonds': penalized_bonds,
            'Portfolio': serialize_dataframe(Portfolio),
            'payment_dates': serialize_dataframe(payment_dates),
            'df_fx_rates' : serialize_dataframe(df_fx_rates),
            "df_swap_rates" : serialize_dataframe(df_swap_rates),
            "coupon_cash_flow_bbg" : serialize_dataframe(coupon_cash_flow_bbg),
            "notional_cash_flow_bbg" : serialize_dataframe(notional_cash_flow_bbg),
            'download_from_bbg': download_from_bbg,
            "folder" : folder
        }

        response = self.request(
            endpoint="/fct_buy_and_hold_analysis",
            method='post',
            data=json_dict,
        )
        response_json = response.json()
        if response.status_code == 200:
            df_response = unserialize_dataframe(response_json)
            return df_response
        else:
            raise ValueError(response_json)

    def fct_optimizer(self, universe, list_constraints, reinv_rate, recovery_rate,
                      df_swap_rates, currency_fund, folder):
        """
        function that launch the optimizer that computes the optimized weights and portfolio on the given universe
        given the constraints
        """

        # json dict will be send via POST requests
        json_dict = {
            "universe" : serialize_dataframe(universe),
            "list_constraints" : list_constraints,
            "reinv_rate" : reinv_rate,
            "recovery_rate" : recovery_rate,
            "df_swap_rates" : serialize_dataframe(df_swap_rates),
            "currency_fund" : currency_fund,
            "folder" : folder
        }

        response = self.request(
            endpoint="/fct_optimizer",
            method='post',
            data=json_dict,
        )
        response_json = response.json()
        if response.status_code == 200:
            df_response = unserialize_dataframe(response_json)
            return df_response
        else:
            raise ValueError(response_json)

    def fct_xirr(self, valuesPerDate):
        """
        function that computes the yields of the Buy&Hold portfolio
        """
        # json dict will be send via POST requests
        json_dict = {
            'valuesPerDate': valuesPerDate
        }

        response = self.request(
            endpoint="/fct_xirr",
            method='post',
            data=json_dict,
        )
        response_json = response.json()
        if response.status_code == 200:
            # df_response = unserialize_dataframe(response_json)
            df_response = response_json
            return df_response
        else:
            raise ValueError(response_json)

    def attempt(self,df):
        """
        attempt
        """
        # json dict will be send via POST requests
        json_dict = {
            'df': serialize_dataframe(df),
        }

        response = self.request(
            endpoint="/attempt",
            method='post',
            data=json_dict,
        )
        response_json = response.json()
        if response.status_code == 200:
            df_response = unserialize_dataframe(response_json)
            return df_response
        else:
            raise ValueError(response_json)



if __name__ == '__main__':
    QRG_api = QRGFixedIncomeApi()

#    print(QRG_api.get_status())
